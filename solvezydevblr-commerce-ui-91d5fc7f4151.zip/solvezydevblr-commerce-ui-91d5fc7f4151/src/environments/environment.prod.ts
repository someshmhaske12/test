export const environment = {
  production: true,
  url : 'https://apis.solvezy.net',
  urlqa : 'https://apis-qa.solvezy.net',
  urlpreprod : 'https://apis-pp.solvezy.net',
};

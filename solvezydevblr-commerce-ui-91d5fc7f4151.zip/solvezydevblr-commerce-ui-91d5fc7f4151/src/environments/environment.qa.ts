export const environment = {
    production: false,
    url : 'https://apis-qa.solvezy.net'
  };

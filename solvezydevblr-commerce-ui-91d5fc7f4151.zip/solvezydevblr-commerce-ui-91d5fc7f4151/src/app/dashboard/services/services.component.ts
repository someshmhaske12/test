import { Component, OnInit } from '@angular/core';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { StorageService } from 'src/app/shared/common/storage-service';
import { NotifyService } from 'src/app/shared/common/notify.service';
@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss'],
})
export class ServicesComponent implements OnInit {
  public solvId: any;

  constructor(private iab: InAppBrowser,
              private storage:StorageService,
              private notifyService:NotifyService) {
      }
  
  ngOnInit() {}

  gotoscf(){
    this.storage.getAccessToken().then(accessToken=>{
      this.storage.getRefreshToken().then(refreshToken=>{
        const browser = this.iab.create(`https://scf-demo.solvezy.net/redirect?accessToken=${accessToken}&refreshToken=${refreshToken}`);
      }).catch(err=>{
        this.notifyService.showToast("Unable to fetch login details!","Dismiss");
      });
    }).catch(err=>{
      this.notifyService.showToast("Unable to fetch login details!","Dismiss");
    });
  }
}

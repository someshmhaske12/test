import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { HomeComponent } from './home/home.component';
import { MoreComponent } from './more/more.component';
import { ServicesComponent } from './services/services.component';
import{SearchComponent}from'./search/search.component';
import{MyconnectionsComponent}from './myconnections/myconnections.component';

const routes: Routes = [
  { path: '', component: DashboardComponent,
    children: [
      { path: 'services', component: ServicesComponent },
      { path: 'more', component: MoreComponent},
      { path: 'home', component: HomeComponent},
      { path: 'search', component: SearchComponent},
      {path: 'myconnections', component: MyconnectionsComponent},
      {
        path: 'chat',
        loadChildren: () => import('../chat/chat.module').then(m => m.ChatModule)
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }

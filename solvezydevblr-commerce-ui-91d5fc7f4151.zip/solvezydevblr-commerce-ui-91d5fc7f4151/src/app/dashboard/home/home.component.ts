import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../dashboard.service';
import { Router } from '@angular/router';
import { AppCommonDataModel } from 'src/app/shared/common/app-common.datamodel';
import { CommonService } from 'src/app/shared/common/common-service';
import { environment } from 'src/environments/environment';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { ChatPanelService } from 'src/app/chat/providers/chat.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  public items = [];
  public smeProfile = [];
  mySmeId: string;
  slideOpts = {
    initialSlide: 0,
    speed: 400,
    autoplay: true,
    // pagination: {
    //   el: '.swiper-pagination',
    //   clickable: true,
    //   renderBullet: function (index, className) {
    //     return '<span class="' + className + '">' + (index + 1) + '</span>';
    //   },
    // }
    };

  constructor(
    private dashboardService: DashboardService,
    private router: Router,
    private dataModel: AppCommonDataModel,
    private commonService: CommonService,
    private notifyService: NotifyService,
    private chatPanelService: ChatPanelService
  ) {}

  async ngOnInit() {
    // alert('ivwe');
    this.mySmeId = await this.commonService.store.getSmeId();
    // alert(this.mySmeId);
    let connected  = this.chatPanelService.getConnectedStatus();
    if (!connected) {
      this.chatPanelService.login(this.mySmeId, '12345');
    }
    this.fetchHomeData();
  }

  doRefresh(event) {
    this.notifyService.showToast('Refreshing');
    this.fetchHomeData();
    event.target.complete();
  }

  fetchHomeData() {
    this.dashboardService.homedata().subscribe((success: any) => {
      // TODO success
      if (success == null || success.data == null) {
        return;
      }
      // TODO remove duplicates
      this.items = success.data.product.slice(0, 4);
      this.smeProfile = success.data.smeProfile;
      this.dataModel.recommondedSmeProfile = success.data.smeProfile.slice(
        0,
        4
      );
      this.dataModel.setProducts(success.data.product.slice(0, 4));
      // console.log(this.items);
    });
  }
  profile() {
    console.log('Routing to complete profile');
    this.router.navigateByUrl('/profile');
  }

  goToProfile(smeId: string) {
    this.router.navigateByUrl('/profile/smeprofile/' + smeId);
  }

  sendConnectRequest(sme) {
    const url = environment.url + '/connect/api/v1/sendconnection';
    const requestObj = {
      requesterSmeId: this.mySmeId,
      targetSmeId: sme.smeId
    };
    sme.connecReqSent = true;
    this.commonService.api.post(url, requestObj).subscribe(
      res => {
        console.log('Sent sucessfully', res);
        this.notifyService.notificationWithClassAndAction(
          'Connection request sent successfully! Yay!!',
          'Okay',
          'blue-snackbar'
        );
      },
      err => {
        // sme.connecReqSent = false;
        console.log('Failed connection request', err);
      }
    );
  }

  getProfileImageUrl(imgkey) {
    if (imgkey === null) {
      return (
        'https://solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com/' +
        'pan/3806270486256868_icon.jpg'
      );
    }
    return (
      'https://solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com/' + imgkey
    );
  }

  getProductImageUrl(imgkey) {
    if (imgkey === null) {
      return (
        'https://solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com/' +
        'pan/3812831593235020_no-image_(1).jpg'
      );
    }
    return (
      'https://solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com/' + imgkey
    );
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-comm-search',
  templateUrl: './comm-search.component.html',
  styleUrls: ['./comm-search.component.scss'],
})
export class CommSearchComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {}
  search(){
    this.router.navigateByUrl('/dashboard/search');
  }

}

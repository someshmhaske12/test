import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserProfile } from 'src/app/user-profile/model/user-profile-models';
import { CommonUserProfileService } from 'src/app/shared/common/common-user-profile-service';
import { AppCommonDataModel } from 'src/app/shared/common/app-common.datamodel';

@Component({
  selector: 'app-more',
  templateUrl: './more.component.html',
  styleUrls: ['./more.component.scss'],
})
export class MoreComponent implements OnInit, AfterViewInit {

  //TODO refactor move to shared data model and reuse
  userProfile:UserProfile = {} as any;
  

  constructor(private router:Router, private cups:CommonUserProfileService, private _dm: AppCommonDataModel) { }

  ngOnInit() {}
  connections(){
    this.router.navigateByUrl('/connect');
  }

  ngAfterViewInit(){
    //TODO refactor, move to common service
    this.cups.updateUerProfile();

  }

  orders(){
    alert("Coming soon");
  }
  help(){
    alert("Coming soon");
  }
  bill(){
    alert("Coming soon");
  }
  payments(){
    alert("Coming soon");
  }
  listing(){
    alert("Coming soon");
  }
  Security(){
    alert("Coming soon");
  }
  Share(){
    alert("Coming soon");
  }
  myBusiness(){
    alert("Coming soon");
  }
  Supply(){
    alert("Coming soon");
  }
  Return(){
    alert("Coming soon");
  }
  Terms(){
    alert("Coming soon");
  }
  Join(){
    alert("Coming soon");
  }
}

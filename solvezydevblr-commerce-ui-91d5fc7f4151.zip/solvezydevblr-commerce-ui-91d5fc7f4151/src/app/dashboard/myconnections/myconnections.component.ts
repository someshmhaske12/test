import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myconnections',
  templateUrl: './myconnections.component.html',
  styleUrls: ['./myconnections.component.scss'],
})
export class MyconnectionsComponent implements OnInit {

  constructor( ) { }

  ngOnInit() {}

}

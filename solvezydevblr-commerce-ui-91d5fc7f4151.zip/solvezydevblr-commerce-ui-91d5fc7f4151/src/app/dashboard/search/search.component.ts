import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import {DashboardService} from '../dashboard.service';
import { Router } from '@angular/router';
import { Profile } from 'selenium-webdriver/firefox';
import { CommonService } from 'src/app/shared/common/common-service';
import { environment } from 'src/environments/environment';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
})
export class SearchComponent implements OnInit, AfterViewInit {
  searching: any;
  file: any;
  public items = [];
  smeProfile: any = [] as any;
  mySmeId: string;
  @ViewChild('searchBar', {static: false}) searchBar: any;
  constructor(private dashboardService: DashboardService,
              private router: Router,
              private commonService: CommonService,
              private notifyService: NotifyService,
              public navCtrl: NavController) { }

  async ngOnInit() {
    this.mySmeId = await this.commonService.store.getSmeId();
  }
  
  ngAfterViewInit() {
    this.searchBar.setFocus();
  }
  back() {
    // this.router.navigate(['dashboard/home']);
    this.navCtrl.back();
  }

  search(event) {
    this.searching = event.target.value;

    this.dashboardService.searchdata(this.searching).subscribe(
        success => {
          // TODO success
          console.log(success);
          this.items = success.data.product;
          this.smeProfile = success.data.smeProfile;
          console.log(this.smeProfile);

          console.log(this.items);
        }
      );
  }

  getImageUrl(imgkey){
    if (imgkey === null) {
      return 'https://solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com/' +  'pan/3806270486256868_icon.jpg';
    }
    return 'https://solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com/' + imgkey;
  }

  goToProfile(smeId: string) {
    this.router.navigateByUrl('/profile/smeprofile/' + smeId);
  }

  sendConnectRequest(sme) {
    const url = environment.url + '/connect/api/v1/sendconnection';
    const requestObj = {
      requesterSmeId: this.mySmeId,
      targetSmeId: sme.smeId
    };
    sme.connecReqSent = true;
    this.commonService.api.post(url, requestObj).subscribe(
      res => {
        console.log('Sent sucessfully', res);
        this.notifyService.notificationWithClassAndAction(
          'Connection request sent successfully! Yay!!',
          'Okay',
          'blue-snackbar'
        );
      },
      err => {
        sme.connecReqSent = false;
        console.log('Failed connection request', err);
      }
    );
  }
}

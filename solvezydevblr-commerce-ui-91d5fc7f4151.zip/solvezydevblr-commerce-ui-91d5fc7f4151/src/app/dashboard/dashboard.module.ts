import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { IonicModule } from '@ionic/angular';
import { MaterialCustomModule } from '../shared/material-custom/material-custom.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppCommonModule } from '../shared/common/app-common.module';
import { DashboardComponent } from './dashboard.component';
import { CommNavbarComponent } from './comm-navbar/comm-navbar.component';
import { CommSearchComponent } from './comm-search/comm-search.component';
import { HomeComponent } from './home/home.component';
import { MoreComponent } from './more/more.component';
import { ServicesComponent } from './services/services.component';
import { SearchComponent } from './search/search.component';
import{MyconnectionsComponent} from './myconnections/myconnections.component';


@NgModule({
  declarations: [DashboardComponent, CommNavbarComponent,CommSearchComponent,HomeComponent,MoreComponent,ServicesComponent,SearchComponent,MyconnectionsComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    HttpClientModule,
    IonicModule,
    MaterialCustomModule,
    ReactiveFormsModule,
    FormsModule,
    AppCommonModule,
    
  ]
})
export class DashboardModule { }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-comm-navbar',
  templateUrl: './comm-navbar.component.html',
  styleUrls: ['./comm-navbar.component.scss'],
})
export class CommNavbarComponent implements OnInit {
  public homeBtnSrc: string = 'assets/drawable/drawable/drawable/home_filled.svg';
  public chatBtnSrc: string = 'assets/drawable/drawable/ic_chat.svg';
  public serviceBtnSrc: string = 'assets/drawable/drawable/group.svg';
  public moreBtnSrc: string = 'assets/drawable/drawable/combined_shape.svg';

  constructor(private router: Router) { }

  ngOnInit() { }


  chat() {
    this.homeBtnSrc = 'assets/drawable/drawable/home.svg';
    this.chatBtnSrc = 'assets/drawable/drawable/drawable/ic_chat_filled.svg';
    this.serviceBtnSrc = 'assets/drawable/drawable/group.svg';
    this.moreBtnSrc = 'assets/drawable/drawable/combined_shape.svg';
  }

  more() {
    this.homeBtnSrc  = 'assets/drawable/drawable/home.svg';
    this.chatBtnSrc = 'assets/drawable/drawable/ic_chat.svg';
    this.serviceBtnSrc = 'assets/drawable/drawable/group.svg';
    this.moreBtnSrc = 'assets/drawable/drawable/drawable/ic-more.svg';
  }

  service() {
    this.serviceBtnSrc = 'assets/drawable/drawable/drawable/ic_services_filled.svg';
    this.homeBtnSrc = 'assets/drawable/drawable/home.svg';
    this.chatBtnSrc = 'assets/drawable/drawable/ic_chat.svg';
    this.moreBtnSrc = 'assets/drawable/drawable/combined_shape.svg';
  }

  home() {
    this.homeBtnSrc = 'assets/drawable/drawable/drawable/home_filled.svg';
    this.chatBtnSrc = 'assets/drawable/drawable/ic_chat.svg';
    this.serviceBtnSrc = 'assets/drawable/drawable/group.svg';
    this.moreBtnSrc = 'assets/drawable/drawable/combined_shape.svg';
  }

  tabChanged(event) {
    const tab: string = event.tab;
    if (tab === 'home') {
      this.home();
    } else if (tab === 'chat') {
      this.chat();
    } else if (tab === 'services') {
      this.service();
    } else if (tab === 'more') {
      this.more();
    }
  }

}

import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonService } from '../shared/common/common-service';
import { Observable } from 'rxjs';
import {environment} from '../../environments/environment';
import { AppCommonDataModel } from '../shared/common/app-common.datamodel';
import { MockService } from '../shared/common/mock-service';
import { NotifyService } from '../shared/common/notify.service';

@Injectable({
  providedIn: 'root'
})

export class DashboardService {
  private urlbase = environment.url;
  private searchUrl =
    this.urlbase + '/commerce/api/v1/search';
    private homeUrl= this.urlbase + '/commerce/api/v1/feed-service?page=1';
  constructor(private _c: CommonService,  
    private _dm:AppCommonDataModel,
    private mockService:MockService,
    private notifyService: NotifyService,
    private commonService: CommonService) { 
      
    
}
searchdata(searching){
  // const headers = new HttpHeaders({
  //   'type':'all',
  //   'query':searching
  // });

  return this.commonService.api.get(this.searchUrl + '?' + 'query=' + searching + '&type=all');
}
homedata(){
  return this.commonService.api.get(this.homeUrl);
}
}



import { Component } from '@angular/core';
import { OnboardingService } from '../onboarding.service';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';


@Component({
  templateUrl: 'onboarding-welcome.html',
  styleUrls: ['onboarding-welcome.scss']
})
export class OnboardingWelcomeComponent {
  public solvId: any;
  constructor(
    private onboardingService: OnboardingService,
    private router: Router,
    private navController: NavController,
    private iab: InAppBrowser
    ) {
    this.solvId = this.onboardingService.getSolvId();
  }
  gotoscf(){
    const accessToken = this.onboardingService.getaccessToken();
    const refreshToken = this.onboardingService.getrefreshToken();
    const browser = this.iab.create(`http://scf-demo.solvezy.net/redirect?accessToken=${accessToken}&refreshToken=${refreshToken}`);
  }
  logout(){
    this.router.navigate(['/onboarding/signin']);
  }
  gotoProfile() {
    this.navController.setDirection('root');
    this.router.navigate(['/profile']);
  }
}

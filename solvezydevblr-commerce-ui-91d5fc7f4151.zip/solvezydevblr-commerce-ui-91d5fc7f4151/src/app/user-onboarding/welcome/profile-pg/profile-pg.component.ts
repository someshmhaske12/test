import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-pg',
  templateUrl: './profile-pg.component.html',
  styleUrls: ['./profile-pg.component.scss'],
})
export class ProfilePgComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

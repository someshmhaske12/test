import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-pg',
  templateUrl: './dashboard-pg.component.html',
  styleUrls: ['./dashboard-pg.component.scss'],
})
export class DashboardPgComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

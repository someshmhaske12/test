import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IGstOtp, IUser } from './models/onboarding-model';
import { NavController } from '@ionic/angular';
import { environment } from 'src/environments/environment';
import { NotifyService } from '../shared/common/notify.service';
import { CommonService } from '../shared/common/common-service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OnboardingService {
  private urlbase = environment.url;
  private gstotpurl = this.urlbase + '/onboarding/api/v1/otp/validategstotp';
  // private userregisterurl =
  //   this.urlbase + '/onboarding/api/v1/user/signup';
  // private usersigninurl =
  //   this.urlbase + '/onboarding/api/v1/user/signin';
  private sendotp = this.urlbase + '/onboarding/api/v1/user/sendotp';
  private verifyotpurl = this.urlbase + '/onboarding/api/v1/user/verifyotp';
  // private createCustomer =
  //   this.urlbase + '/onboarding/api/v1/createCustomer';
  private createCustomerByGstIn =
    this.urlbase + '/onboarding/api/v1/createcustomerbygstin?gstin=';
  private onboardingDocUrl =
    this.urlbase + '/onboarding/api/v1/uploadOnboardingDocument';
  private downloadonboardingDocUrl =
    this.urlbase + '/onboarding/api/v1/downloadOnboardingDocument';
  private addAtrributeUrl =
    this.urlbase + '/onboarding/api/v1/user/addattributes';
  private getAtrributeUrl =
    this.urlbase + '/onboarding/api/v1/user/getattributes';

 

  // private saveonboardingdocumentdetails =
  //   'https://apis.solvezy.net/onboarding/api/v1/saveonboardingdocumentdetails';

//PROFILE-->BUSINESS-->ADDLOGO
// https://apis.solvezy.net/commerce/api/v1/upload-document

private profileaddlogo =
this.urlbase + '/commerce/api/v1/upload-document';

private logokey =
this.urlbase + '/commerce/api/v1/profile';


  galleryClicked = new EventEmitter<string>();

  private onboardCustomer =
  'https://apis.solvezy.net/onboarding/api/v1/onboardCustomer';

  //TODO refactor data model
  private gstData: any;
  private gstObj: any;
  private gstResubmit = false;
  private user: IUser = {} as any;
  private otpRequestId;
  public accessToken;
  private idToken;
  private refreshToken;
  private requestId: any;
  private solvId: any;
  private fileData: File;
  private clientId = '4e15m4p5l9886529mib8t5t1uu';
  private mobileprefix = '+91';
  private signUpFlag = false;
  constructor(private http: HttpClient, 
    private navController: NavController, 
    private _c:CommonService) {}

  userRegistration(formdata, email) {
    this.user.name = formdata.name;
    this.user.email = email;
    this.user.mobile = this.mobileprefix + formdata.mobile;
    this._c.store.setUserPhoneNum(this.user.mobile);
    // const data = {
    //   mobile: this.mobileprefix + formdata.mobile,
    //   name: formdata.name,
    //   email,
    //   clientId: this.clientId
    // };
    return this.http.post(this.sendotp + `?mobile=${this.user.mobile}`, {});
  }

  setOtpReqId(reqId: string, signUpFlag) {
    this.otpRequestId = reqId;
    this.signUpFlag = signUpFlag;
  }

  setAccessTokens(accessToken, idToken, refreshToken) {
    this.accessToken = accessToken;
    this.idToken = idToken;
    this.refreshToken = refreshToken;
    this._c.store.setAccessTokenToLocalStorage(accessToken);
    this._c.store.setRefreshToken(refreshToken);
    console.log('Set Access token to local Storage');

  }
  userLogin(formdata) {
    this.user.mobile = this.mobileprefix + formdata.mobile;
    this._c.store.setUserPhoneNum(this.user.mobile);
    // const data = {
    //   mobile: this.mobileprefix + formdata.mobile
    // };
    return this.http.post(this.sendotp + `?mobile=${this.user.mobile}`, {});
  }

  resendOtp() {
    return this.http.post(this.sendotp + `?mobile=${this.user.mobile}`, {});
  }

  verifyotp(otp) {
    const otpdata = {
      mobile: this.user.mobile,
      email: this.user.email ? this.user.email : null,
      name: this.user.name ? this.user.name : '',
      otp,
      clientId: this.clientId,
      otpRequestId: this.otpRequestId,
      isSignUp: this.signUpFlag
    };
    return this.http.post(this.verifyotpurl, otpdata);
  }

  gstotp(otp) {
    const data: IGstOtp = {
      gstin: this.gstObj.gstin || '10AAZCS7084G1ZW',
      userName:
        this.gstObj.userName ||
        'Standard Chartered Research and Technology India Private Limited',
      otp,
      requestId: this.requestId || '02f5e1bb-0ea2-11e9-9e49-773a357cd5db',
      consent: 'Y',
      mobileNo: this.user.mobile
    };

    return this.http.post(this.gstotpurl, data);
  }

  createCustByGstIn() {
    const headers = new HttpHeaders({
      'accessToken': this.accessToken
    });
    const options = { headers };

    const gstIn = this.gstObj.gstin;
    const url = this.createCustomerByGstIn + gstIn;
    console.log(options);
    return this.http.post(url, {}, options);
  }

  uploadDoc(selctdoc, file) {
    console.log('uploadDoc', selctdoc, file);
    const headers = new HttpHeaders({
      'X-CORE-IDENTIFIER': selctdoc
    });
    const options = { headers };
    const formData: FormData = new FormData();
    formData.append('file', file);
    return this.http.post(this.onboardingDocUrl, formData, options);
  }

  proceedToNext(url:string, gstin:string, userName:string):  Observable<any>{
    let gstinObject = { gstin, userName };
    this.setGstObj(gstinObject);
    return this._c.api.post(url,gstinObject);
  }

  checkStatus(url:string): Observable<any> {
    return this._c.api.get(url, false);
  }

  downloadOnboardingDocument() {
    const headers = new HttpHeaders({
      'X-FILE-KEY':
        '1568356471258_f5860dca-bdf3-40fb-b4c5-856feb338763-190408_Horizon_Draft_Terms_of_Service_-_Trilegal_Edits_190411.docx',
      'X-REQUEST-ID': 'test'
    });

    return this.http.get(this.downloadonboardingDocUrl, {
      responseType: 'arraybuffer',
      headers
    });
  }

  docDetails(doc) {
    console.log('docDetails', doc);
    return this.http.post(this.onboardCustomer, doc);
  }

  setUserAttribute() {
    const data = {
      mobile: this.user.mobile,
      clientId: this.clientId,
      userAttribute: {
        name: 'solvId',
        value: this.solvId
      }
    };
    return this.http.post(this.addAtrributeUrl, data);
  }

  getUserAttribute() {
    const data = {
      mobile: this.user.mobile,
      clientId: this.clientId
    };
    return this.http.post(this.getAtrributeUrl, data);
  }

//Profile--> Business --> add logo

addlogo(file) {
  const headers = new HttpHeaders({
    DOCUMENT_TYPE: 'PROFILE_LOGO'
  });
  const options = { headers };
  const formData: FormData = new FormData();
  formData.append('file', file);
  return this.http.post(this.profileaddlogo, formData, options);
}

logo(imgkey) {
  console.log('docDetails', imgkey);
  return this.http.put(this.logokey, imgkey);
}

//Profile--> Business --> add factory Images
addFactory(file) {
  const headers = new HttpHeaders({
    DOCUMENT_TYPE: 'FACTORY'
  });
  const options = { headers };
  const formData: FormData = new FormData();
  formData.append('file', file);
  return this.http.post(this.profileaddlogo, formData, options);
}

//Profile--> Product --> product Image

addproductImg(file) {
  const headers = new HttpHeaders({
    DOCUMENT_TYPE: ' PRODUCT_CATLOG'
  });
  const options = { headers };
  const formData: FormData = new FormData();
  formData.append('file', file);
  return this.http.post(this.profileaddlogo, formData, options);
}



  getResubmitStatus() {
    return this.gstResubmit;
  }
  setResubmitStatus(status) {
    this.gstResubmit = status;
  }
  setGstData(gst) {
    this.gstData = gst;
  }
  getGstData() {
    return this.gstData;
  }
  getFileData() {
    return this.fileData;
  }
  setFileData(file) {
    this.fileData = file;
  }
  setGstObj(gst) {
    this.gstObj = gst;
  }
  setRequestId(id) {
    this.requestId = id;
  }
  setSolvId(solvId) {
    this.solvId = solvId;
  }
  getSolvId() {
    return this.solvId;
  }
  backClicked() {
    this.navController.pop();
  }
  getUser() {
    return this.user;
  }
  getaccessToken() {
    return this.accessToken;
  }

  getrefreshToken() {
    return this.refreshToken;
  }

  getImageUrl(imgkey){
    return 'https://solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com/' + imgkey;
  }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-page',
  templateUrl: './admin.component.html'
})
export class AdminComponent {
  constructor() {}
}

import { Injectable } from '@angular/core';


@Injectable({
    providedIn: 'root'
})
export class CustomerModel {
    private gstin: String;
    private phno: number;
    private solvId: String;

    public getGstin(): String {
        return this.gstin;
    }

    public setGstin(gstin: String): void {
        this.gstin = gstin;
    }

    public getPhno(): number {
        return this.phno;
    }

    public setPhno(phno: number): void {
        this.phno = phno;
    }

    public getSolvId(): String {
        return this.solvId;
    }

    public setSolvId(solvId: String): void {
        this.solvId = solvId;
    }
}
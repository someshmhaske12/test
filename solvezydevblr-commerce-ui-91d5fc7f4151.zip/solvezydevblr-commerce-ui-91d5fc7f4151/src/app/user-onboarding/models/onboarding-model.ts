export interface IGstOtp {
  gstin: string;
  userName: string;
  otp: string;
  requestId: string;
  consent: string;
  mobileNo: string;
}

export interface IUser {
    name: string;
    email: string;
    mobile: string;
}

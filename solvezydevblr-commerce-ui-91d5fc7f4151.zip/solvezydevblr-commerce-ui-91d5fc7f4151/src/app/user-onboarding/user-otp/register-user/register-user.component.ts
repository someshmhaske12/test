import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { OnboardingService } from '../../onboarding.service';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.scss']
})
export class RegisterUserComponent {
  buttonFlag = false;
  i18nObj = {
    register: 'Register your account',
    registertext:
      'Onboard yourself with mobile OTP and GST OTP verification & create an instant business profile'
  };

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private navController: NavController,
    private onboardingService: OnboardingService,
    private notifyService: NotifyService
  ) {}

  ionViewDidEnter() {
    document.addEventListener("backbutton",function(e) {
      console.log("disable back button")
    }, false);
}

  registrationForm = this.formBuilder.group({
    name: new FormControl('', [Validators.required, Validators.maxLength(50)]),
    mobile: new FormControl('', [
      Validators.required,
      Validators.maxLength(10),
      Validators.minLength(10)
    ]),
    terms: new FormControl(true, Validators.pattern('true'))
  });

  email = new FormControl('', [Validators.email, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z]{3,}([.]{1}[a-zA-Z]{2,}|[.]{1}[a-zA-Z]{2,}[.]{1}[a-zA-Z]{2,})')]);

  getErrorMessage() {
    return this.email.hasError('pattern') ? 'Not a valid email' :
            '';
  }

  onFormSubmit() {
    this.buttonFlag = true;
    this.notifyService.createLoader();
    this.onboardingService
      .userRegistration(this.registrationForm.value, this.email.value)
      .subscribe(
        (res: any) => {
          console.log(res);
          if (res.data.status === 'Success') {
            this.onboardingService.setOtpReqId(
              res.data.otpRequestId, true
            );
            this.notifyService.dismissLoader();
            this.navController.setDirection('root');
            this.router.navigate(['/onboarding/otp']);
          }
          this.notifyService.dismissLoader();
        },
        err => {
          console.log(err);
          if (err.error.errorCode === 'C1006') {
            console.log('user already created');
            this.notifyService.showToast('User already exists', 'error');
          }
          this.navController.setDirection('root');
          this.notifyService.dismissLoader();
        }
      );
  }

  tnc() {
    this.onboardingService
      .downloadOnboardingDocument()
      .subscribe(res => this.downLoadFile(res, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'));
  }

  /**
   * Method is use to download file.
   * @param data - Array Buffer data
   * @param type - type of the document.
   */
  downLoadFile(data: any, type: string) {
    const blob = new Blob([data], { type });
    const url = window.URL.createObjectURL(blob);
    const pwa = window.open(url);
    if (!pwa || pwa.closed || typeof pwa.closed === 'undefined') {
      alert('Please disable your Pop-up blocker and try again.');
    }
  }

  back() {
    this.navController.setDirection('root');
    this.router.navigateByUrl('/onboarding/tutorial');
  }

  signIn() {
    this.navController.setDirection('root');
    this.router.navigateByUrl('/onboarding/signin');
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { timer } from 'rxjs';
import { NavController } from '@ionic/angular';
import { CommonService } from 'src/app/shared/common/common-service';
import { environment } from 'src/environments/environment'
import { UserProfile } from 'src/app/user-profile/model/user-profile-models';
import { NotifyService } from 'src/app/shared/common/notify.service';

@Component({
  selector: 'app-user-mobile-verified',
  templateUrl: './user-mobile-verified.component.html',
  styleUrls: ['./user-mobile-verified.component.scss']
})
export class UserMobileVerifiedComponent implements OnInit {
  constructor(private router: Router,
  private navController: NavController,
  private commonService: CommonService,
  private notifyService:NotifyService) {}
  
  ionViewDidEnter() {
    document.addEventListener("backbutton",function(e) {
      console.log("disable back button")
    }, false);
}

  ngOnInit() {
    timer(3000).subscribe(() => {
      this.navController.setDirection('root');
      this.commonService.store.getUserPhoneNumber().then((num) => {
        const phoneNumWithCountryCode = '+91' + num;
        const url = environment.url + '/onboarding/api/v1/verificationstatus' + '?mobile=' + encodeURIComponent(phoneNumWithCountryCode);
        this.commonService.api.getWithTextResponse(url, false).subscribe(
          (res: any) => {
            if(res === 'ACTIVE') {
              this.router.navigateByUrl('/dashboard/home');
            } else if (res === 'PENDING') {
              this.router.navigateByUrl('/onboarding/company-wait-approval');
            } else {
              this.router.navigate(['/onboarding/usergst']);
            }
          },
          (err) => {

            this.commonService.store.getSmeId().then((smeId) => {
              if (smeId === null) {
                this.router.navigate(['/onboarding/usergst']);
              } else {
                const getSmeProfile = environment.url + '/commerce/api/v1/profile?smeId=' + smeId;
                this.commonService.api.get(getSmeProfile, false).subscribe((success: any) => {
                  if(success.data.profileDetail != null) {
                    let dm: UserProfile;
                    dm = success.data.profileDetail;
                    if (dm.solvId === null) {
                      this.router.navigate(['/onboarding/usergst']);
                    } else {
                      this.router.navigate(['/dashboard/home']);
                    }
                  }
                },
                error=>{
                  this.notifyService.showToast("Can't find user profile. Please contact the customer support!", "Close", 10000);
                });
              }
            });
          });
      });
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { OnboardingService } from '../../onboarding.service';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { NavController } from '@ionic/angular';
import { CommonService } from 'src/app/shared/common/common-service'
@Component({
  selector: 'app-user-signin',
  templateUrl: './user-signin.component.html',
  styleUrls: ['./user-signin.component.scss']
})
export class UserSigninComponent {
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private onboardingService: OnboardingService,
    private notifyService: NotifyService,
    private navController: NavController,
    public commonService: CommonService
  ) {}

  signinForm = this.formBuilder.group({
    mobile: new FormControl('', [
      Validators.required,
      Validators.maxLength(10),
      Validators.minLength(10)
    ])
  });

  ionViewDidEnter() {
    document.addEventListener("backbutton",function(e) {
      console.log("disable back button")
    }, false);
}

  onFormSubmit() {
    if (this.signinForm.value.mobile === '1111122222') {
      this.navController.setDirection('root');
      this.router.navigate(['/onboarding/admin']);
      return;
    }
    this.notifyService.createLoader();
    this.onboardingService.userLogin(this.signinForm.value).subscribe(
      (res: any) => {
        console.log(res);
        if (res.data.status === 'Success') {
          this.commonService.store.setUserPhoneNum(this.signinForm.value.mobile);
          this.onboardingService.setOtpReqId(
            res.data.otpRequestId, false
          );

          this.notifyService.dismissLoader();
          this.navController.setDirection('root');
          this.router.navigate(['/onboarding/otp']);
          // this.navController.navigateForward('/onboarding/otp');
        }
      }
      // ,
      // err => {
      //   this.notifyService.showToast('Error while generating OTP!');
      //   this.notifyService.dismissLoader();
      // }
    );
    // this.router.navigate(['/onboarding/otp']);
  }

  back() {
    this.navController.setDirection('root');
    this.router.navigateByUrl('/onboarding/tutorial');
  }

  signUp() {
    // this.onboardingService.signUp();
    this.navController.setDirection('root');
    this.router.navigateByUrl('/onboarding/register');
  }
}

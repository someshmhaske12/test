import { Component, OnInit } from '@angular/core';
import { OnboardingService } from '../../onboarding.service';
import { Router } from '@angular/router';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { IUser } from '../../models/onboarding-model';
import { NavController } from '@ionic/angular';
import { CommonService } from 'src/app/shared/common/common-service';
import { AppCommonDataModel } from 'src/app/shared/common/app-common.datamodel';
import { FcmService } from 'src/app/shared/common/fcm-service';

@Component({
  selector: 'app-register-otp',
  templateUrl: './register-otp.component.html',
  styleUrls: ['./register-otp.component.scss']
})
export class RegisterOtpComponent implements OnInit {
  otp: string;
  showOtpComponent = true;
  OTP = '';
  hash: any;
  showOTPInput = false;
  user: IUser = {} as any;
  otpFailedFlag = false;

  config = {
    allowNumbersOnly: true,
    length: 4,
    inputStyles: {
      width: '50px',
      height: '50px',
      'border-radius': '30px',
      border: 'solid 2px #003399',
      'margin-right': '20px'
    }
  };

  constructor(
    private onboardingService: OnboardingService,
    private router: Router,
    private notifyService: NotifyService,
    private navController: NavController,
    private dm: AppCommonDataModel,
    private commonService: CommonService,
    private fcmService: FcmService
  ) {}

  ngOnInit() {
    this.user = this.onboardingService.getUser();
    // this.genHash();
    // this.retriveSms();
  }

  ionViewDidEnter() {
    document.addEventListener('backbutton', (e) => {
      console.log('disable back button');
    }, false);
}
  onOtpChange(otp) {
    this.otp = otp;
  }

  onConfigChange() {
    this.showOtpComponent = false;
    setTimeout(() => {
      this.showOtpComponent = true;
    }, 0);
  }

  // genHash() {
  //   this.smsRetriever
  //     .getAppHash()
  //     .then((res: any) => {
  //       this.hash = res;
  //       alert(this.hash);
  //     })
  //     .catch((error: any) => console.error(error));
  // }

  // retriveSms() {
  //   console.log('waitingSms');
  //   this.smsRetriever
  //     .startWatching()
  //     .then((res: any) => {
  //       console.log(res);
  //       const otp = res.Message.toString().substr(4, 8);
  //       // alert(`otp received - ${otp}`);
  //     })
  //     .catch((error: any) => console.error(error));
  // }

  activate() {
    if (this.otp.length === 4) {
      console.log(this.otp);
      this.onboardingService.verifyotp(this.otp).subscribe(
        (res: any) => {
          console.log(res);
          this.onboardingService.setAccessTokens(
            res.data.accessToken,
            res.data.idToken,
            res.data.refreshToken
          );
          this.commonService.store.getUserPhoneNumber().then((phoneNum) => {
            this.fcmService.sendToken(phoneNum);
          });
          this.onboardingService.getUserAttribute().subscribe(
            (resattr: any) => {
              console.log(resattr.data);
              let solvidFlag = false;
              resattr.data.forEach(element => {
                if (element.name === 'custom:solvId') {
                  solvidFlag = true;
                  this.commonService.store.setSolvId(element.value);
                }

                if (element.name === 'custom:smeId') {
                  this.dm.userProfile.smeId = element.value;
                  this.setSmeId(element.value);
                }
              });

              if (solvidFlag) {
                this.navController.setDirection('root');
                this.router.navigateByUrl('/dashboard/home');
              } else {
                this.navController.setDirection('root');
                this.router.navigateByUrl('/onboarding/mobileverified');
              }
            },
            err => {
              this.notifyService.showToast('Error', 'Error');
            }
          );
        },
        err => {
          if (
            err.error.errorMessage[0].includes(
              'An account with the given phone_number already exists.'
            )
          ) {
            this.notifyService.showToast('Account exists. Please sign in');
            this.navController.setDirection('root');
            this.router.navigateByUrl('/onboarding/signin');
          } else if (
            err.error.errorMessage[0].includes(
              'Error in Otp validation, please try again'
            )
          ) {
            this.notifyService.showToast('OTP Not Valid');
            this.otp = '';
            this.onConfigChange();
            this.otpFailedFlag = true;
          } else if (
            err.error.errorMessage[0].includes('User does not exist.')
          ) {
            this.notifyService.showToast(
              'User not registered, please Sign up first!'
            );
            this.navController.setDirection('root');
            this.router.navigateByUrl('/onboarding/register');
          }
        }
      );
    }
  }

  resend() {
    this.onboardingService.resendOtp().subscribe();
    this.notifyService.showToast('OTP Resent');
  }

  changeNumber() {
    this.navController.setDirection('root');
    this.router.navigateByUrl('/onboarding/signin');
  }

  back() {
    this.navController.setDirection('root');
    if (this.user.name) {
      this.router.navigateByUrl('/onboarding/register');
    } else {
      this.router.navigateByUrl('/onboarding/signin');
    }
  }

  async setSmeId(smeId) {
    await this.commonService.store.setSmeId(smeId);
  }
}

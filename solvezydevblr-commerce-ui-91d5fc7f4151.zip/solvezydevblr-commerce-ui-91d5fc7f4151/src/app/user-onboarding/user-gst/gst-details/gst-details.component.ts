import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { OnboardingService } from '../../onboarding.service';
import { environment } from 'src/environments/environment';
import { NavController } from '@ionic/angular';
import { NotifyService } from 'src/app/shared/common/notify.service';

@Component({
  selector: 'app-gst-details',
  templateUrl: './gst-details.component.html',
  styleUrls: ['./gst-details.component.scss']
})
export class GstDetailsComponent implements OnInit {
  public lingualObj = {
    head: 'Make your business profile through GST',
    otpHead: 'Thankyou for enabling OTP.',
    otpHead2: 'You can verify your GST now',
    subHead: 'Please verify your GST to create a credible business profile',
    errorHead : 'Please Enter a Valid GST',
    gstNo: 'GST No.',
    gstName: 'GST User Name',
    submit: 'Submit',
    bottomText: 'Don’t have GST?'
  };
  public reSubmitStatus = false;

  constructor(
    private router: Router,
    private onboardingService: OnboardingService,
    private fb: FormBuilder,
    private navController: NavController,
    private notifyService: NotifyService
  ) {}

  gstForm = this.fb.group({
    gstin: new FormControl('', [Validators.required, Validators.maxLength(15)]),
    userName: new FormControl('', [
      Validators.required
    ])
  });

  ngOnInit() {
    this.reSubmitStatus = this.onboardingService.getResubmitStatus();
  }

  proceedtonext() {
    console.log("proceed to next api: "+this.gstForm.value);
    const url = environment.url + '/onboarding/api/v1/otp/generategstotp';
    const gstin = this.gstForm.value.gstin;
    const userName = this.gstForm.value.userName;
    
    this.onboardingService.proceedToNext(url, gstin, userName).subscribe(
      (res: any)=>{
        console.log(res);
        if (res.statusCode === 200) {
          const data = res.data;
          if (data !== null && data.statusCode === '102') {
            console.log('102');
            this.onboardingService.setRequestId(data.requestId);
            this.navController.setDirection('root');
            this.router.navigate(['/onboarding/enableotp']);
          } else if (data !== null && data.statusCode === '101') {
            console.log('101');
            this.onboardingService.setRequestId(data.requestId);
            if (data.result.status_cd === '1') {
              this.navController.setDirection('root');
              this.router.navigate(['/onboarding/gstotp']);
            } else {
              this.navController.setDirection('root');
              this.router.navigate(['/onboarding/enableotp']);
            }
          }
        }
      },
      (err: any) => {
          this.notifyService.notificationWithClassAndAction('Please Provide a Valid Gst No', 'Okay','blue-snackbar');
          console.log(err);
        }
    );
  }

  dontHaveGst() {
    this.navController.setDirection('root');
    this.router.navigate(['/onboarding/nongst']);
  }
}
// 050680

import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { InstructionPageComponent } from '../instruction-page/instruction-page.component';
import { Router } from '@angular/router';
import { ClientService } from 'src/app/client.service';
import { ModalController, LoadingController, NavController } from '@ionic/angular';
import { OnboardingService } from '../../onboarding.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-enable-otp',
  templateUrl: './enable-otp.component.html',
  styleUrls: ['./enable-otp.component.scss']
})
export class EnableOtpComponent implements OnInit {
  public dialogRef: MatDialogRef<InstructionPageComponent>;
  public lingualObj = {
    blueHead: 'GST OTP enabled',
    info: 'If your GST notification is not enabled, you learn how to enable it by one tap',
    showHow: 'Show me how',
    or: 'OR',
    uploadTxt: 'You can just upload GST document'
  };

  constructor(
    public dialog: MatDialog,
    private router: Router,
    private onboardingService: OnboardingService,
    public loadingController: LoadingController,
    private clientService: ClientService,
    public modalController: ModalController,
    private navController: NavController
  ) {}

  ngOnInit() {}

  async presentModal() {
    const modal = await this.modalController.create({
      component: InstructionPageComponent
    });
    return await modal.present();
  }

  async presentLoadingWithOptions() {
    const loading = await this.loadingController.create({
      spinner: 'circles',
      message: 'Please wait...',
      translucent: true,
      cssClass: 'custom-class custom-loading'
    });
    return await loading.present();
  }

  handleFileInput(files) {
    const formData = new FormData();
    formData.append('file', files.item(0));
    const url = environment.url + '/onboarding/api/v1/uploadGST';
    this.presentLoadingWithOptions();
    this.clientService.postClientData(url, formData).subscribe(
      (res: any) => {
        console.log('res');
        console.log(res);
        this.loadingController.dismiss();
        // let data = JSON.parse(res.data);
        // res.data = data;
        this.onboardingService.setGstData(res);
        this.onboardingService.setFileData(files.item(0));
        this.router.navigate(['/onboarding/userupload']);
      },
      err => {
        this.loadingController.dismiss();
      }
    );
  }

  back() {
    this.navController.setDirection('root');
    this.router.navigateByUrl('/onboarding/usergst');
  }
}

import { Component, OnInit } from '@angular/core';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser/ngx'
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-instruction-page',
  templateUrl: './instruction-page.component.html',
  styleUrls: ['./instruction-page.component.scss'],
})
export class InstructionPageComponent implements OnInit {

  constructor(private iab: InAppBrowser, public modalCtrl: ModalController) { }
  options: InAppBrowserOptions = {
    location: 'yes',//Or 'no' 
    hidden: 'no', //Or  'yes'
    clearcache: 'yes',
    clearsessioncache: 'yes',
    zoom: 'yes',//Android only ,shows browser zoom controls 
    hardwareback: 'yes',
    mediaPlaybackRequiresUserAction: 'no',
    shouldPauseOnSuspend: 'no', //Android only 
    closebuttoncaption: 'Close', //iOS only
    disallowoverscroll: 'no', //iOS only 
    toolbar: 'yes', //iOS only 
    toolbarposition: 'top',
    enableViewportScale: 'no', //iOS only 
    allowInlineMediaPlayback: 'no',//iOS only 
    presentationstyle: 'pagesheet',//iOS only 
    fullscreen: 'yes',//Windows only   
    footer: 'yes',
    hidenavigationbuttons: 'yes'

  };
  public lingualObj = {
    head: 'For retrieving the GST report via OTP, You’ll have to first login to to www.gst.gov.in and enable API access .',
    watchVideo: 'Watch a video how to enable',
    or: 'Or Follow the below steps',
    info1: 'Login to',
    link: 'www.gst.gov.in',
    info2: 'Go to View Profile',
    info3: "Under the quick link tab click on ‘Manage API Access’",
    info4: 'Enable API Request',
    login: 'Login now to enable'
  }
  ngOnInit() { }
  // public openWithInAppBrowser(url: string) {
  //   let target = "_blank"; 
  //   this.iab.create(url, target, this.options);
  // }
  public openWithCordovaBrowser(url: string) {
    let target = "_self";
    this.iab.create(url, target, this.options);
  }
  public openWithSystemBrowser(url: string) {
    let target = "_system";
    this.iab.create(url, target, this.options);
    this.modalCtrl.dismiss({
      'dismissed': true
    });
  }
  dismiss() {
    // using the injected ModalController this page
    // can "dismiss" itself and optionally pass back data
    this.modalCtrl.dismiss({
      'dismissed': true
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClientService } from 'src/app/client.service';
import { OnboardingService } from '../../onboarding.service';
import { environment } from 'src/environments/environment';
import { NavController } from '@ionic/angular';
import { EnableOtpComponent } from '../enable-otp/enable-otp.component';
import { NgControlStatus } from '@angular/forms';
import { CommonService } from 'src/app/shared/common/common-service'

@Component({
  selector: 'app-gst-upload',
  templateUrl: './gst-upload.component.html',
  styleUrls: ['./gst-upload.component.scss']
})
export class GstUploadComponent implements OnInit {
  public gstData: any;
  gst = '';
  constructor(
    private router: Router,
    private onboardingService: OnboardingService,
    public navCtrl: NavController,
    private clientService: ClientService,
    private commonService: CommonService
  ) {}
  public lingualObj = {
    blueHead: 'Upload GST certificate',
    info:
      'Seems like your GST notification is not enabled, you can upload your GST certificate.',
    cardSub:
      'Take a photo of your GST certificate and upload to verify your business',
    uploadDoc: '1 document',
    uploaded: 'Uploaded',
    delete: 'Delete',
    save: 'Submit',
    fileName: 'Doc',
    fileSize: ''
  };
  ngOnInit() {
    console.log('User Upload');
    this.gstData = this.onboardingService.getGstData();
    console.log(this.gstData);
    if (this.gstData) {
      this.gst = JSON.parse(this.gstData.data).registration_number;
    }
    const file = this.onboardingService.getFileData();
    console.log(file);
    if (file) {
      this.lingualObj.fileName = file.name ? file.name : 'file not found';
      const size = Math.ceil(file.size / 1024).toString() + 'kb';
      this.lingualObj.fileSize = size;
    }
  }
  back() {
    console.log('test');
    this.navCtrl.setDirection('root');
    this.router.navigateByUrl('/onboarding/enableotp');
  }
  save() {
    const url = environment.url + '/onboarding/api/v1/createCustomer';
    this.clientService
      .postClientData(url, this.gstData, this.onboardingService.accessToken)
      .subscribe((res: any) => {
        this.onboardingService.setSolvId(JSON.parse(res.data).data.solvId);
        this.commonService.store.setSolvId(JSON.parse(res.data).data.solvId);
        this.navCtrl.setDirection('root');
        this.router.navigate(['/dashboard/home']);
        // /v1/gst/createCustomer
      });
  }
  retake() {
    this.navCtrl.setDirection('root');
    this.router.navigate(['/onboarding/enableotp']);
  }
  // back() {
  //   this.onboardingService.backClicked();
  // }
}

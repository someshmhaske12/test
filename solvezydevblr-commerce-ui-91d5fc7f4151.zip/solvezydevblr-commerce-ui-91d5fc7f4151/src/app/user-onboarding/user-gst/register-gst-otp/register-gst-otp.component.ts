import { Component, OnInit } from '@angular/core';
import { OnboardingService } from '../../onboarding.service';
import { Router } from '@angular/router';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { NavController } from '@ionic/angular';
import { CommonService } from 'src/app/shared/common/common-service'

@Component({
  selector: 'app-register-gst-otp',
  templateUrl: './register-gst-otp.component.html',
  styleUrls: ['./register-gst-otp.component.scss']
})
export class RegisterGstOtpComponent {
  otp: string;
  showOtpComponent = true;
  otpFailedFlag = false;

  constructor(
    private onboardingService: OnboardingService,
    private router: Router,
    private notifyService: NotifyService,
    private navController: NavController,
    private commonService: CommonService
  ) {}

  config = {
    allowNumbersOnly: true,
    length: 6,
    inputStyles: {
      width: '35px',
      height: '35px',
      'border-radius': '30px',
      border: 'solid 1.5px #003399'
    }
  };

  onOtpChange(otp) {
    this.otp = otp;
  }

  onConfigChange() {
    this.showOtpComponent = false;
    setTimeout(() => {
      this.showOtpComponent = true;
    }, 0);
  }

  verify() {
    if (this.otp.length === 6) {
      this.onboardingService.gstotp(this.otp).subscribe((res: any) => {
        if (res.statusCode === 200) {
          const data = res.data;
          if (data !== null && data.statusCode === '101') {
            if (data.result && data.result.status_cd === '1') {
              this.onboardingService
                .createCustByGstIn()
                .subscribe((rescust: any) => {
                  this.onboardingService.setSolvId(rescust.data.solvid);
                  this.commonService.store.setSolvId(rescust.data.solvid);
                  this.onboardingService.setUserAttribute();
                  this.navController.setDirection('root');
                  this.router.navigate(['/dashboard/home']);
                });
            } else {
              this.notifyService.showToast('Please Retry Again');
              this.otpFailedFlag = true;
            }
          } else if (data !== null) {
            this.notifyService.showToast('Please Retry Again');
            this.otpFailedFlag = true;
          } else {
            this.notifyService.showToast('Please Retry Again');
            this.otpFailedFlag = true;
          }
        }
      });
    }
  }

  //   data: {statusCode: "101", requestId: "5b1e6950-ef1d-41c3-92d0-e6f8881287c1", result: {status_cd: "1"}}
  // requestId: "5b1e6950-ef1d-41c3-92d0-e6f8881287c1"
  // result: {status_cd: "1"}
  // status_cd: "1"
  // statusCode: "101"
  // errorCode: "0"
  // errorMessage: null
  // requestId: null
  // status: "Success"
  // statusCode: 200

  // resend() {

  // }

  back() {
    this.navController.setDirection('root');
    this.router.navigateByUrl('/onboarding/usergst');
  }

  // changeNumber() {
  //   this.navController.setDirection('root');
  //   this.router.navigateByUrl('/onboarding/usergst');
  // }
}

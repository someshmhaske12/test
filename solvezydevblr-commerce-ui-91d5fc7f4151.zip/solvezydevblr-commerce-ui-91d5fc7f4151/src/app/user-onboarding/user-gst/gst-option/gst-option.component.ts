import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { InstructionPageComponent } from '../instruction-page/instruction-page.component';
import { Router } from '@angular/router';
import { ClientService } from 'src/app/client.service';
import { ModalController, LoadingController } from '@ionic/angular';
import { OnboardingService } from '../../onboarding.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-gst-option',
  templateUrl: './gst-option.component.html',
  styleUrls: ['./gst-option.component.scss']
})
export class GstOptionComponent implements OnInit {
  constructor(
    public dialog: MatDialog,
    private router: Router,
    private onboardingService: OnboardingService,
    public loadingController: LoadingController,
    private clientService: ClientService,
    public modalController: ModalController
  ) {}
  public dialogRef: MatDialogRef<InstructionPageComponent>;
  public lingualObj = {
    blueHead: 'Please select any one to proceed',
    resubmit: 'Resubmit GST',
    or: 'OR',
    uploadTxt: 'Upload GST certificate',
    ifNoGst: 'No GST? if you don’t have GST',
    otherkyc :'Verify with other KYC'
  };
  ngOnInit() {}

  goToUserGst(){
    this.router.navigate(['/onboarding/usergst'])
  }
  async presentLoadingWithOptions() {
    const loading = await this.loadingController.create({
      spinner: 'circles',
      message: 'Please wait...',
      translucent: true,
      cssClass: 'custom-class custom-loading'
    });
    return await loading.present();
  }

  handleFileInput(files) {
    const formData = new FormData();
    formData.append('file', files.item(0));
    const url = environment.url + '/onboarding/api/v1/uploadGST';
    this.presentLoadingWithOptions();
    this.clientService.postClientData(url, formData).subscribe(
      res => {
        console.log('res');
        console.log(res);
        this.loadingController.dismiss();
        this.onboardingService.setGstData(res);
        this.router.navigate(['/onboarding/userupload']);
      },
      err => {
        this.loadingController.dismiss();
      }
    );
  }
  back() {
    this.onboardingService.backClicked();
  }
}

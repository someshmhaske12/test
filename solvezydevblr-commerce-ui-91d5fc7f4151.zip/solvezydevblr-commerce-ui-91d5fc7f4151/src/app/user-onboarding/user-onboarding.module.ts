import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MaterialCustomModule } from '../shared/material-custom/material-custom.module';
import { AppCommonModule } from '../shared/common/app-common.module';

import { UserOnboardingRoutingModule } from './user-onboarding-routing.module';
import { RegisterUserComponent } from './user-otp/register-user/register-user.component';
import { RegisterOtpComponent } from './user-otp/register-otp/register-otp.component';
import { UserMobileVerifiedComponent } from './user-otp/user-mobile-verified/user-mobile-verified.component';
import { UserSigninComponent } from './user-otp/user-signin/user-signin.component';
import { TutorialPageComponent } from './tutorial-page/tutorial-page.component';
import { HttpClientModule } from '@angular/common/http';
import { GstDetailsComponent } from './user-gst/gst-details/gst-details.component';
import { EnableOtpComponent } from './user-gst/enable-otp/enable-otp.component';
import { GstUploadComponent } from './user-gst/gst-upload/gst-upload.component';

import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { InstructionPageComponent } from './user-gst/instruction-page/instruction-page.component';
import { OnboardingWelcomeComponent } from './welcome/onboarding-welcome.component';
import { RegisterGstOtpComponent } from './user-gst/register-gst-otp/register-gst-otp.component';
import { NoUserGstComponent } from './no-user-gst/no-user-gst.component';
import { NonGstDocumentComponent } from './no-user-gst/non-gst-document/non-gst-document.component';
import { OnboardingPendingComponent } from './no-user-gst/onboarding-pending/onboarding-pending.component';
import { GstOptionComponent } from './user-gst/gst-option/gst-option.component';
import { AdminComponent } from './admin/admin.component';
import { DashboardPgComponent } from './welcome/dashboard-pg/dashboard-pg.component';
import { ProfilePgComponent } from './welcome/profile-pg/profile-pg.component';
import { CompanyInfoComponent } from './no-user-gst/company-info/company-info.component';
import { CompanyWaitApprovalComponent } from './no-user-gst/company-wait-approval/company-wait-approval.component';
import { NongstBtmsheetComponent } from './no-user-gst/nongst-btmsheet/nongst-btmsheet.component';
import { NongstuploadBtmsheetComponent } from './no-user-gst/nongstupload-btmsheet/nongstupload-btmsheet.component';

@NgModule({
  declarations: [
    RegisterUserComponent,
    RegisterOtpComponent,
    UserSigninComponent,
    UserMobileVerifiedComponent,
    TutorialPageComponent,
    GstDetailsComponent,
    EnableOtpComponent,
    GstUploadComponent,
    InstructionPageComponent,
    OnboardingWelcomeComponent,
    RegisterGstOtpComponent,
    NoUserGstComponent,
    NonGstDocumentComponent,
    OnboardingPendingComponent,
    GstOptionComponent,
    OnboardingPendingComponent,
    AdminComponent,
    DashboardPgComponent,
    ProfilePgComponent,
    CompanyInfoComponent,
    CompanyWaitApprovalComponent,
    NongstBtmsheetComponent,
    NongstuploadBtmsheetComponent
  ],
  entryComponents: [InstructionPageComponent,
                    NongstBtmsheetComponent,
                    NongstuploadBtmsheetComponent],
  imports: [
    CommonModule,
    UserOnboardingRoutingModule,
    HttpClientModule,
    IonicModule,
    MaterialCustomModule,
    ReactiveFormsModule,
    FormsModule,
    AppCommonModule
  ],
  providers: [InAppBrowser]
})
export class OnboardingModule {}



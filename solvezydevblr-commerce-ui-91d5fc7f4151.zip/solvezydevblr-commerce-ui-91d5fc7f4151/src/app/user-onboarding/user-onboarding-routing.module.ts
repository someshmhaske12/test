import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegisterUserComponent } from './user-otp/register-user/register-user.component';
import { RegisterOtpComponent } from './user-otp/register-otp/register-otp.component';
import { UserMobileVerifiedComponent } from './user-otp/user-mobile-verified/user-mobile-verified.component';
import { UserSigninComponent } from './user-otp/user-signin/user-signin.component';
import { TutorialPageComponent } from './tutorial-page/tutorial-page.component';
import { GstDetailsComponent } from './user-gst/gst-details/gst-details.component';
import { EnableOtpComponent } from './user-gst/enable-otp/enable-otp.component';
import { GstUploadComponent } from './user-gst/gst-upload/gst-upload.component';
import { InstructionPageComponent } from './user-gst/instruction-page/instruction-page.component';
import { OnboardingWelcomeComponent } from './welcome/onboarding-welcome.component';
import { RegisterGstOtpComponent } from './user-gst/register-gst-otp/register-gst-otp.component';
import { NoUserGstComponent } from './no-user-gst/no-user-gst.component';
import { NonGstDocumentComponent } from './no-user-gst/non-gst-document/non-gst-document.component';
import { OnboardingPendingComponent } from './no-user-gst/onboarding-pending/onboarding-pending.component';
import { TutorialGuard } from './../shared/common/tutorial.guard';
import { GstOptionComponent } from './user-gst/gst-option/gst-option.component';
import { AdminComponent } from './admin/admin.component';
import { DashboardPgComponent } from './welcome/dashboard-pg/dashboard-pg.component';
import { ProfilePgComponent } from './welcome/profile-pg/profile-pg.component';
import { CompanyInfoComponent } from './no-user-gst/company-info/company-info.component';
import { CompanyWaitApprovalComponent } from './no-user-gst/company-wait-approval/company-wait-approval.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'tutorial',
    pathMatch: 'full'
  },
  { path: 'tutorial', component: TutorialPageComponent },
  { path: 'register', component: RegisterUserComponent },
  { path: 'otp', component: RegisterOtpComponent },
  { path: 'signin', component: UserSigninComponent },
  { path: 'mobileverified', component: UserMobileVerifiedComponent },
  { path: 'usergst', component: GstDetailsComponent },
  { path: 'enableotp', component: EnableOtpComponent },
  { path: 'userupload', component: GstUploadComponent },
  { path: 'instructionpage', component: InstructionPageComponent },
  { path: 'gstotp', component: RegisterGstOtpComponent },
  { path: 'solvid', component: OnboardingWelcomeComponent },
  { path: 'nongst', component: NoUserGstComponent },
  { path: 'nongstdoc', component: NonGstDocumentComponent },
  { path: 'nongstpending', component: OnboardingPendingComponent },
  { path: 'gstoption', component: GstOptionComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'dash', component: DashboardPgComponent },
  { path: 'profile', component: ProfilePgComponent },
  { path: 'company-info', component: CompanyInfoComponent },
  { path: 'company-wait-approval', component: CompanyWaitApprovalComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserOnboardingRoutingModule { }

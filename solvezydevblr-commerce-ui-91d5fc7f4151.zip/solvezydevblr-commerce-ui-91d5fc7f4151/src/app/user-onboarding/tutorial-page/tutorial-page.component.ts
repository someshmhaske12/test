import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { Storage } from '@ionic/storage';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-tutorial-page',
  templateUrl: './tutorial-page.component.html',
  styleUrls: ['./tutorial-page.component.scss']
})
export class TutorialPageComponent {
  // slideOptions = {
  //   loop: false,
  //   preloadImages: true,
  //   lazy: false
  // };

  // features = {
  //   pagination: '.swiper-pagination',
  //   slidesPerView: 1,
  //   preloadImages: true,
  //   lazy: false,
  //   paginationClickable: true,
  //   // paginationBulletRender(className) {
  //   //   return '<span class="' + className + '">' +'</span>';
  //   // }
  // };
  constructor(
    private router: Router,
    private navController: NavController) {}


    ionViewDidEnter() {
      document.addEventListener("backbutton",function(e) {
        console.log("disable back button")
      }, false);
  }
  finish() {
    // todo store if tutorial has been completed
    // await this.storage.set('tutorialComplete', true);
    this.navController.setDirection('root');
    this.router.navigateByUrl('/onboarding/register');
  }

  ionViewDidLoad() {
    console.log('loaded');
  }
}

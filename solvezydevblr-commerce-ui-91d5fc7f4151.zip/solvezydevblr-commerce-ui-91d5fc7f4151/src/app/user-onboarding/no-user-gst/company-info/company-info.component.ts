import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-company-info',
  templateUrl: './company-info.component.html',
  styleUrls: ['./company-info.component.scss'],
})
export class CompanyInfoComponent implements OnInit {
  docs: any[] = [
    { value: 'licence', viewValue: 'Establishment License' },
    { value: 'adhar', viewValue: 'Udhyog Aadhar' },
    { value: 'certificate', viewValue: 'Trade Certificate/License' },
    { value: 'registration', viewValue: 'FSSAI Registration' }
  ];
  constructor(
              private formBuilder: FormBuilder,
              private router: Router
            ) { }

  infoForm = this.formBuilder.group({
  businessType: new FormControl('', Validators.required),
  industryType: new FormControl('', Validators.required)
            });

  ngOnInit() {}

  onFormSubmit() {
    console.log('hello');
  }

  back() {
    // todo
  }
}

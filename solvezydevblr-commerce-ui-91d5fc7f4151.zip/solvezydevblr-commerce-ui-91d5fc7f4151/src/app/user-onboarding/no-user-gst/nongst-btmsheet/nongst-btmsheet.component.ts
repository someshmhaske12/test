import { Component, OnInit, Inject } from '@angular/core';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { OnboardingService } from '../../onboarding.service';
import { NotifyService } from '../../../shared/common/notify.service';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { MatBottomSheet} from '@angular/material/bottom-sheet';
import { NongstuploadBtmsheetComponent } from '../nongstupload-btmsheet/nongstupload-btmsheet.component';


@Component({
  selector: 'app-nongst-btmsheet',
  templateUrl: './nongst-btmsheet.component.html',
  styleUrls: ['./nongst-btmsheet.component.scss'],
})
export class NongstBtmsheetComponent implements OnInit {
  fileoptsobj;
  files: any;
  toshow:any;
  otpFailedFlag = false;
  constructor(private bottomSheetRef: MatBottomSheetRef<NongstBtmsheetComponent>,
              @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
              private onboardingService: OnboardingService,
              private notifyService: NotifyService,
              private camera: Camera,
              private bottomSheet: MatBottomSheet) { }

  ngOnInit() {
    console.log(this.data.formData, 'formData');
  }

  cross(){
    this.bottomSheetRef.dismiss(); 
  }
  openCamera(): void {
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    };
    this.camera.getPicture(options).then(
      (imageData) => {
        this.files = 'data:image/jpeg;base64,' + imageData;
        console.log( this.files);

        // this.imageDoc(this.files);
      },
      err => {
        // Handle error
        console.log('Camera issue:' + err);
      }
    );
  }
  
  openGalery(event): void {
    this.files = event.target.files[0];
    this.imageDoc(event.target.files[0]);
  }

  imageDoc(files) {
    console.log(this.data.formData.value.selectedDoc);
    this.onboardingService
      .uploadDoc(this.data.formData.value.selectedDoc, files)
      .subscribe(
        (img: any) => {

          console.log(img);
          this.toshow = img.data.key;
          console.log(this.toshow);
          const user = this.onboardingService.getUser();
          // this.notifyService.loader.dismiss();
          this.fileoptsobj = {
            documentType: this.data.formData.value.selectedDoc,
            // emailAddress: user.email ? user.email : 'sadd@dad.com',
            // entityName: 'test2',
            fileKey: img.data.key,
            // gstNumber: 'test2',
            pan: this.data.formData.value.pan,
            mobile: user.mobile ? user.mobile : '+919999994888',
            platformType: 'COMMERCE',
            verificationStatus: 'PENDING'
          };
          console.log(this.fileoptsobj);
          this.bottomSheet.open(NongstuploadBtmsheetComponent, {
            data : this.fileoptsobj,
          });
          this.onboardingService.galleryClicked.emit(this.fileoptsobj);
          this.otpFailedFlag = true;
        },
        err => {
          this.notifyService.showToast('Please try again');
          this.otpFailedFlag = true;
          console.log('errerr');
          console.log(err);
        }
      );
  }
}

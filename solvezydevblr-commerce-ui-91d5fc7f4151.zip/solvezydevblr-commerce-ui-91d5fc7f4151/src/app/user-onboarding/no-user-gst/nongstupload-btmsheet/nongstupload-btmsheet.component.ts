import { Component, OnInit, Inject } from '@angular/core';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { NongstBtmsheetComponent } from '../nongst-btmsheet/nongst-btmsheet.component';
import { OnboardingService } from 'src/app/user-onboarding/onboarding.service';
import { NotifyService } from 'src/app/shared/common/notify.service';

@Component({
  selector: 'app-nongstupload-btmsheet',
  templateUrl: './nongstupload-btmsheet.component.html',
  styleUrls: ['./nongstupload-btmsheet.component.scss'],
})
export class NongstuploadBtmsheetComponent implements OnInit {
  sendkey;
  allData:any;
  imgURL: string  | ArrayBuffer;
  constructor(private bottomSheetRef: MatBottomSheetRef<NongstBtmsheetComponent>,
              @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
              private onboardingService: OnboardingService,
              private notifyService: NotifyService,) { }

  ngOnInit( ) {
    console.log("reached here")
   this.allData = this.data;
   this.imageShow();
  }
  cross(){
    this.bottomSheetRef.dismiss();
  }

  imageShow() {
    this.imgURL = this.onboardingService.getImageUrl(this.allData.fileKey);
  }

  submit() {
    this.bottomSheetRef.dismiss();
  }
}

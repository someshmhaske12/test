import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NongstuploadBtmsheetComponent } from './nongstupload-btmsheet.component';

describe('NongstuploadBtmsheetComponent', () => {
  let component: NongstuploadBtmsheetComponent;
  let fixture: ComponentFixture<NongstuploadBtmsheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NongstuploadBtmsheetComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NongstuploadBtmsheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

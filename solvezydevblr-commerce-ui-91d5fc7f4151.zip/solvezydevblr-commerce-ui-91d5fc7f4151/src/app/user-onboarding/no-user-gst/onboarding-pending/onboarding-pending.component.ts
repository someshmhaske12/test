import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onboarding-pending',
  templateUrl: './onboarding-pending.component.html',
  styleUrls: ['./onboarding-pending.component.scss'],
})
export class OnboardingPendingComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

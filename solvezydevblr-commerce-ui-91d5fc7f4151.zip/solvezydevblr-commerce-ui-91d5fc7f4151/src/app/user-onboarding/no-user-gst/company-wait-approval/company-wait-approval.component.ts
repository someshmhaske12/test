import { Component, OnInit } from '@angular/core';
import { OnboardingService } from '../../onboarding.service';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { CommonService } from 'src/app/shared/common/common-service';
import { environment } from 'src/environments/environment';




@Component({
  selector: 'app-company-wait-approval',
  templateUrl: './company-wait-approval.component.html',
  styleUrls: ['./company-wait-approval.component.scss'],
})
export class CompanyWaitApprovalComponent implements OnInit {

  constructor(
    private onboardingService: OnboardingService,
    private router: Router,
    private notifyService: NotifyService,
    private navController: NavController,
    private commonService: CommonService) { }

  ngOnInit() {}

  doRefresh(refresher) {
    this.notifyService.showToast('refreshing');
    console.log('Begin async operation', refresher);

    setTimeout(() => {
      console.log('Async operation has ended');
      refresher.complete();
    }, 1000);
  }

  gotoProfile () {
    this.navController.setDirection('root');
    this.router.navigateByUrl('/profile');
  }

  checkStatus() {
    this.commonService.store.getUserPhoneNumber().then((phoneNum: any) => {
      let phoneNumWithCountryCode = '+91' + phoneNum;
      const url = environment.url + '/onboarding/api/v1/verificationstatus' + '?mobile=' + encodeURIComponent(phoneNumWithCountryCode);
      this.commonService.api.getWithTextResponse(url, false).subscribe(
        (res: any) => {
          if (res === 'ACTIVE') {
            this.router.navigateByUrl('/dashboard/home');
          } else if (res === 'PENDING') {
            this.notifyService.notificationWithClassAndAction('Your document verification is still pending', 'Okay','blue-snackbar');
          } else if (res === 'FAILED') {
            this.notifyService.notificationWithClassAndAction('Your document verification failed, please contact support', 'Okay', 'blue-snackbar');
          }
        },
        (err: any) => {
          this.notifyService.notificationWithClassAndAction('Something went wrong, Try again', 'Okay','blue-snackbar');
          console.log(err);
        }
      );
    });
    
  }

  back() {
    this.onboardingService.backClicked();
  }
  goToprofile(){
    this.router.navigate(['profile']);
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OnboardingService } from '../../onboarding.service';
import { ClientService } from 'src/app/client.service';
import { environment } from 'src/environments/environment';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-non-gst-document',
  templateUrl: './non-gst-document.component.html',
  styleUrls: ['./non-gst-document.component.scss']
})
export class NonGstDocumentComponent implements OnInit {
  public gstData: any;
  constructor(
    private router: Router,
    private onboardingService: OnboardingService,
    private clientService: ClientService,
    private navController: NavController
  ) {}
  public lingualObj = {
    head: 'Upload ',
    blueHead: 'File',
    cardHead: 'File type',
    cardSub: 'Upload your file to verify your business',
    uploadDoc: '1 document',
    uploaded: 'Uploaded',
    delete: 'Delete',
    save: 'Save'
  };
  ngOnInit() {
    this.gstData = this.onboardingService.getGstData();
   }
  save() {
    // PAN,UDYOG_AADHAAR,ESTABLISHMENT_LICENSE,TRADE_LICENSE,FSSAI_REG
    const url =
      environment.url + '/onboarding/api/v1/saveonboardingdocumentdetails';
    const data = {
      documentType: 'PAN',
      fileKey:
        '1568291374444_c7ac1e19-f611-46c2-a5a5-fcdbcf33056d-Neojit_GST_Certificate-nonmca.pdf', // service
      mobile: '8220346066', // service
      pan: 'CMSPK29999G', // service
      verificationStatus: 'PENDING'
    };
    this.clientService.postClientData(url, data).subscribe((res: any) => {
      // this.onboardingService.setSolvId(JSON.parse(res.data).data.solvId)
      this.router.navigate(['/onboarding/nongstpending']);
      // /v1/gst/createCustomer

      //       data: "Successfully Updated Document Details"
      // errorCode: 0
      // errorMessage: null
      // requestId: null
      // status: "Success"
      // statusCode: 200
    });
  }

  delete() {
    this.navController.setDirection('root');
    this.router.navigate(['/onboarding/enableotp']);
  }

  back() {
    this.navController.setDirection('root');
    this.router.navigate(['/onboarding/enableotp']);
  }
}

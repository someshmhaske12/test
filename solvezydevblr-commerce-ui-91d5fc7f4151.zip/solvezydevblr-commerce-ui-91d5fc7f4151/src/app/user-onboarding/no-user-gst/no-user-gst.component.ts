import { Component, OnInit } from '@angular/core';
import { OnboardingService } from '../onboarding.service';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { MatBottomSheet} from '@angular/material/bottom-sheet';

import {FormBuilder,FormGroup,FormControl,Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { NonGstDocumentComponent } from './non-gst-document/non-gst-document.component';
import { NongstBtmsheetComponent } from './nongst-btmsheet/nongst-btmsheet.component';

@Component({
  selector: 'app-no-user-gst',
  templateUrl: './no-user-gst.component.html',
  styleUrls: ['./no-user-gst.component.scss']
})
export class NoUserGstComponent implements OnInit {
  files: any;
  otpFailedFlag = false;
  fileuploaded:any;
  docs: any[] = [
    { value: 'ESTABLISHMENT_LICENSE', viewValue: 'Establishment License' },
    { value: 'UDYOG_AADHAAR', viewValue: 'Udhyog Aadhar' },
    { value: 'TRADE_LICENSE', viewValue: 'Trade Certificate/License' },
    { value: 'FSSAI_REG', viewValue: 'FSSAI Registration' }
  ];

  currentImage: any;
  fileoptsobj;
  constructor(
    private onboardingService: OnboardingService,
    private formBuilder: FormBuilder,
    private camera: Camera,
    private router: Router,
    private notifyService: NotifyService,
    private bottomSheet: MatBottomSheet
  ) {
    this.onboardingService.galleryClicked.subscribe((responsebottom) => {
      console.log(responsebottom, 'response obtained');
      this.fileuploaded = responsebottom;
    });
  }
  // options: CameraOptions = {
  //   quality: 100,
  //   destinationType: this.camera.DestinationType.FILE_URI,
  //   encodingType: this.camera.EncodingType.JPEG,
  //   mediaType: this.camera.MediaType.PICTURE,
  //   correctOrientation: true,
  //   sourceType: 1
  // };
  gstForm = this.formBuilder.group({
    pan: new FormControl('', [Validators.required, Validators.maxLength(10)]),
    selectedDoc: new FormControl('', Validators.required)
  });

  ngOnInit() {}
  ionViewDidEnter() {
    document.addEventListener("backbutton",function(e) {
      console.log("disable back button")
    }, false);
}
  back() {
    this.onboardingService.backClicked();
  }

  openGaleryBtmSheet(): void {
    this.bottomSheet.open(NongstBtmsheetComponent,{
      data: {formData : this.gstForm}
    }
    );
  }

  // takeSnap() {
  //   const options: CameraOptions = {
  //     quality: 100,
  //     destinationType: this.camera.DestinationType.FILE_URI,
  //     encodingType: this.camera.EncodingType.JPEG,
  //     mediaType: this.camera.MediaType.PICTURE
  //     // sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
  //   };
  //   this.camera.getPicture(options).then(
  //     (imageData) => {
  //       this.files = imageData;
  //       console.log( this.files)
  //       this.imageDoc(this.files);
  //     },
  //     err => {
  //       // Handle error
  //       console.log('Camera issue:' + err);
  //     }
  //   );
  // }


  onFormSubmit() {
    console.log(this.fileuploaded);
    this.onboardingService.docDetails(this.fileuploaded).subscribe(
      (res: any) => {
        this.router.navigate(['onboarding/company-wait-approval']);
      },
      err => {
        console.log('errerr');
        console.log(err);
      }
    );
  }
}

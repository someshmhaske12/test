import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConnectRoutingModule } from './connect-routing.module';
import { RouterModule } from '@angular/router';
import { ReceivedConnectionComponent } from './received-connection/received-connection.component';
import { IonicModule } from '@ionic/angular';
import { MaterialCustomModule } from '../shared/material-custom/material-custom.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppCommonModule } from '../shared/common/app-common.module';



@NgModule({
  declarations: [ReceivedConnectionComponent],
  imports: [
    CommonModule,
    ConnectRoutingModule,
    IonicModule,
    MaterialCustomModule,
    ReactiveFormsModule,
    FormsModule,
    AppCommonModule
  ],
  exports: [RouterModule]
})
export class ConnectModule { }

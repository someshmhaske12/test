import { Component, OnInit } from '@angular/core';
import { ConnectService } from '../connect.service';
import { ConnectModel } from '../model/connect-model';
import { StorageService } from 'src/app/shared/common/storage-service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-received-connection',
  templateUrl: './received-connection.component.html',
  styleUrls: ['./received-connection.component.scss'],
})
export class ReceivedConnectionComponent implements OnInit {

  receivedConnectionData:ConnectModel;
  smeId: string;

  constructor(
    private connectService:ConnectService,
    private storageService: StorageService,
    public navCtrl: NavController
    ) { }

  ngOnInit() {
    this.getReceivedRequest();
  }

  async getReceivedRequest() {
    this.smeId  =  await this.storageService.getSmeId();
    console.log("inside getReceivedRequest")
    console.log(this.smeId)
    this.connectService.getReceivedRequest(this.smeId).subscribe((
        res:any)=>{
      console.log(res.data);
      this.receivedConnectionData=res.data;
      console.log(this.receivedConnectionData);
    })   
  }


  getLogoImageUrl(fileKey:string){
    return 'https://solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com/'+fileKey
  }

  acceptRequest(connection:ConnectModel){
    console.log(connection);
    var mySmeId = this.smeId;
    console.log("inside acceptRequest")
    console.log(mySmeId)
    const requestObj = {
        requesterSmeId: connection.smeId,
        targetSmeId: mySmeId
      };
    this.connectService.acceptConnectionRequest(requestObj).subscribe((
        res:any)=>{
      console.log(res.data);
    })   
  }

  back() {
    // this.router.navigate(['dashboard/home']);
    this.navCtrl.back();
  }
}

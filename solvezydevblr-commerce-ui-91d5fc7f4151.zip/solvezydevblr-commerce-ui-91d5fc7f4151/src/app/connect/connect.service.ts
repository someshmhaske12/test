import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConnectService {

  constructor(private http: HttpClient) { }

  receivedConnectionUrl:string = 'https://apis.solvezy.net/commerce/api/v1/fetch-received-connection';

  updateConnectionUrl:string='https://apis.solvezy.net/commerce/api/v1/update-connection'

  getReceivedRequest(smeId:string){
      return this.http.get(this.receivedConnectionUrl+'?smeId='+ smeId,{});
  }
  
  acceptConnectionRequest(connectionObj:any){
      let headers: HttpHeaders;
        headers = new HttpHeaders({
        'connectionType': 'ACCEPTED'
      });
      let options = {headers:headers};
      return this.http.post(this.updateConnectionUrl,connectionObj,options);
  }
}


export interface ConnectModel {
    customerName:string;
    solvId:string;
    smeId:string;
    fileKey:string;
}
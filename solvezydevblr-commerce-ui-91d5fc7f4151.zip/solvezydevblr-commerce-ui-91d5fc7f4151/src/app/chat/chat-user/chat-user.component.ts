import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController, IonContent } from '@ionic/angular';
import { ChatPanelService } from '../providers/chat.service';
import {
  ChatMessageService,
  ChatMessage
} from '../providers/chat-message.service';
import { CommonService } from 'src/app/shared/common/common-service';
import { ChatSmeService } from '../providers/chat-sme.service';
import { first } from 'rxjs/operators';
import { Subscription, from } from 'rxjs';
import { NotifyService } from 'src/app/shared/common/notify.service';

@Component({
  selector: 'app-chat-user',
  templateUrl: './chat-user.component.html',
  styleUrls: ['./chat-user.component.scss']
})
export class ChatUserComponent implements OnInit, OnDestroy {
  jid: string;
  jidId: string;
  msgList: any;
  toUser: any = {};
  user: any = {};
  editorMsg = '';
  msgRecieved: any;
  presenseRecieved: any;
  fileToUpload: any;
  userTyping = false;
  smeName: string;

  msgSubscription: Subscription;
  composingSubscription: Subscription;
  presenseSubscription: Subscription;
  imageSubscription: Subscription;

  @ViewChild('content', {static: false}) private content: any;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private navController: NavController,
    private chatPanelService: ChatPanelService,
    private chatMessageService: ChatMessageService,
    private commonService: CommonService,
    private chatSmeService: ChatSmeService,
    private notifyService: NotifyService
  ) {}

  ngOnInit() {
    this.msgList = [];

    // no need to unsubscribe as paramMap automatically dies
    this.route.params.subscribe(params => {
      this.jid = params.jid;

      this.jidId = this.jid + '@localhost';

      this.toUser = {
        id: this.jidId
      };

      const toName = this.chatMessageService.getName();
      if (!toName) {
        this.getSmeName(this.jid, false);
      } else {
        this.toUser.name = toName;
      }

      this.chatPanelService.setToJid(this.toUser.id);
      this.chatPanelService.settoName(toName);
    });

    this.chatPanelService
      .getConnected()
      .pipe(first())
      .subscribe(connect => {
        this.chatPanelService.retrieveMsgs();
      });

    this.chatMessageService
      .getHistory()
      .pipe(first())
      .subscribe(message => {
        console.log(message);
        this.msgList = message;
      });

    this.msgSubscription = this.chatMessageService
      .getMessage()
      .subscribe(message => {
        this.msgRecieved = message.text.innerHTML;
        console.log('this.msgRecieved');
        console.log(this.msgRecieved);
        this.userTyping = false;

        if (this.msgRecieved.includes('img')) {
          const src = this.extractImgSrc(this.msgRecieved);
          console.log(src);
          const chatmsg: ChatMessage = {
            message: src,
            toUserId: this.user.id,
            userId: this.toUser.id,
            userName: this.toUser.name,
            type: 'img'
          };
          this.pushNewMsg(chatmsg);
          this.scrollToBottom();
        } else {
          const chatmsg: ChatMessage = {
            message: this.msgRecieved,
            toUserId: this.user.id,
            userId: this.toUser.id,
            userName: this.toUser.name,
            type: 'text'
          };
          this.pushNewMsg(chatmsg);
          this.scrollToBottom();
        }
      });

    this.composingSubscription = this.chatMessageService
      .getComposing()
      .subscribe(message => {
        console.log('user typing');
        this.userTyping = true;
      });

    this.presenseSubscription = this.chatMessageService
      .getPresense()
      .subscribe(presense => {
        this.presenseRecieved = presense;
      });

    this.imageSubscription = this.chatMessageService
      .getImageUploaded()
      .subscribe(flag => {
        if (flag.text === 'false') {
          // image upload failed
          // this.notifyService.showToast('image could not be sent');
          console.log('img upload failed');
        } else {
          const chatmsg: ChatMessage = {
            message: flag.text,
            toUserId: this.toUser.id,
            userId: this.user.id,
            userName: this.user.name,
            type: 'img'
          };
          this.pushNewMsg(chatmsg);
          this.scrollToBottom();
        }

      });
  }

  async ionViewWillEnter() {
    const smid = await this.commonService.store.getSmeId();
    this.user.id = smid + '@localhost';
    this.getSmeName(smid, true);

    const connected = this.chatPanelService.getConnectedStatus();
    if (!connected) {
      this.chatPanelService.login(this.user.name, '12345');
    } else {
      this.chatPanelService.retrieveMsgs();
    }

    this.scrollToBottom();
  }

  back() {
    this.navController.setDirection('root');
    // this.router.navigateByUrl('/chat/chatlist');
    this.navController.back();
  }

  sendMsg() {
    if (!this.editorMsg.trim()) {
      return;
    }

    this.chatPanelService.sendMsg(this.editorMsg);

    const chatmsg: ChatMessage = {
      message: this.editorMsg,
      toUserId: this.toUser.id,
      userId: this.user.id,
      userName: this.user.name,
      type: 'text'
    };
    this.pushNewMsg(chatmsg);
    this.scrollToBottom();
    this.editorMsg = '';
  }

  pushNewMsg(msg: ChatMessage) {
    const userId = this.user.id,
      toUserId = this.toUser.id;
    // Verify user relationships
    if (msg.userId === userId && msg.toUserId === toUserId) {
      this.msgList.push(msg);
    } else if (msg.toUserId === userId && msg.userId === toUserId) {
      this.msgList.push(msg);
    }
  }

  fileUpload(files) {
    this.fileToUpload = files.item(0);

    const file = this.fileToUpload;
    const to = this.toUser.id;
    const filename = file.name;
    const filesize = file.size;
    const mime = file.type;

    const imgObj = {
      fileType: mime,
      fileName: filename,
      fileSize: filesize,
      to,
      receiver: to,
      file
    };

    this.chatPanelService.imageUpload(imgObj);
  }

  getSmeName(id, fromflag) {
    let uname;
    this.chatSmeService.getSmeDetails(id).subscribe(smeData => {
      if (smeData.data && smeData.data.customerDetail) {
        uname = smeData.data.customerDetail.customerName;
      } else if (smeData.data && smeData.data.profileDetail) {
        uname = smeData.data.profileDetail.name;
      } else {
        uname = 'unknown user';
      }
      if (fromflag) {
        this.user.name = uname;
        this.chatPanelService.setFromName(uname);
      } else {
        this.toUser.name = uname;
        this.chatPanelService.settoName(uname);
      }
    });
  }

  extractImgSrc(str) {
    const regex = /img.*?src='(.*?)'/;
    const src = regex.exec(str)[1];
    return src;
  }

  scrollToBottom() {
    setTimeout(() => {
      if (this.content.scrollToBottom) {
        this.content.scrollToBottom();
      }
    }, 400);
  }

  ngOnDestroy(): void {
    this.msgSubscription.unsubscribe();
    this.composingSubscription.unsubscribe();
    this.presenseSubscription.unsubscribe();
    // this.chatPanelService.logOut();
  }
}

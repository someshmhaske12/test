import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatRoutingModule } from './chat-routing.module';
import { IonicModule } from '@ionic/angular';
import { MaterialCustomModule } from '../shared/material-custom/material-custom.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppCommonModule } from '../shared/common/app-common.module';
import { ChatListComponent } from './chat-list/chat-list.component';
import { ChatUserComponent } from './chat-user/chat-user.component';

@NgModule({
  declarations: [
    ChatListComponent,
    ChatUserComponent
  ],
  imports: [
    CommonModule,
    ChatRoutingModule,
    IonicModule,
    MaterialCustomModule,
    ReactiveFormsModule,
    FormsModule,
    AppCommonModule
  ],
  entryComponents: [
  ]
})
export class ChatModule {}

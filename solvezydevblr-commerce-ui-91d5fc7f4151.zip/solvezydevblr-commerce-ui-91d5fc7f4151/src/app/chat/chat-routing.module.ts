import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChatListComponent } from './chat-list/chat-list.component';
import { ChatUserComponent } from './chat-user/chat-user.component';



const routes: Routes = [
  {
    path: '',
    redirectTo: 'chatlist',
    pathMatch: 'full'
  },
  { path: 'chatlist', component: ChatListComponent },
  { path: 'chat-user/:jid', component: ChatUserComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class ChatRoutingModule { }

import { Component, OnInit, OnDestroy } from '@angular/core';
import { ChatPanelService } from '../providers/chat.service';
import { ChatListService, InboxMessage } from '../providers/chat-list.service';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { CommonService } from 'src/app/shared/common/common-service';
import { first } from 'rxjs/operators';
import { Observable, forkJoin, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { ChatSmeService } from '../providers/chat-sme.service';
import { ChatMessageService } from '../providers/chat-message.service';
import { NotifyService } from 'src/app/shared/common/notify.service';

@Component({
  selector: 'app-chat-list',
  templateUrl: './chat-list.component.html',
  styleUrls: ['./chat-list.component.scss']
})
export class ChatListComponent implements OnInit, OnDestroy {
  inboxData: InboxMessage[] = [] as any;
  profileData = new Map();

  online: boolean;
  smeId: string;
  smeName: string;
  smes: any = [];

  inboxSubscription: Subscription;
  inboxLoaded = false;

  constructor(
    private chatPanelService: ChatPanelService,
    private chatListService: ChatListService,
    private chatMessageService: ChatMessageService,
    private router: Router,
    private navController: NavController,
    private commonService: CommonService,
    private chatSmeService: ChatSmeService,
    private notifyService: NotifyService
  ) {}

  ngOnInit() {
    this.notifyService.createLoader();
    console.log('on init');
    this.chatPanelService
      .getConnected()
      .pipe(first())
      .subscribe(connect => {
        this.online = true;
        this.chatListService.clearInbox();
        this.chatPanelService.getInbox();
      });

    this.inboxSubscription = this.chatPanelService
      .getInboxCompleted()
      .pipe(first())
      .subscribe(() => {
        console.log('oncomplete');
        this.inboxData = this.chatListService.getInbox();
        console.log(this.inboxData);

        this.inboxData.forEach(inboxdata => {
          if (this.profileData.has(inboxdata.id)) {
            inboxdata.name = this.profileData.get(inboxdata.id);
          } else {
            this.chatSmeService
              .getSmeDetails(inboxdata.id)
              .subscribe(smeData => {
                console.log(smeData);
                if (smeData.data && smeData.data.customerDetail) {
                  inboxdata.name = smeData.data.customerDetail.customerName;
                  this.profileData.set(
                    inboxdata.id,
                    smeData.data.customerDetail.customerName
                  );
                } else if (smeData.data && smeData.data.profileDetail) {
                  inboxdata.name = smeData.data.profileDetail.name;
                  this.profileData.set(
                    inboxdata.id,
                    smeData.data.profileDetail.name
                  );
                } else {
                  inboxdata.name = 'unknown user';
                }
              });
          }
        });
        console.log(this.inboxData);
        this.inboxLoaded = true;
        this.notifyService.dismissLoader();
      });
  }

  async ionViewWillEnter() {
    console.log('ivwe');
    this.smeId = await this.commonService.store.getSmeId();
    this.getLoggedInUSerName(this.smeId);
    const connected = this.chatPanelService.getConnectedStatus();
    if (!connected) {
      this.chatPanelService.login(this.smeId, '12345');
    } else {
      this.chatListService.clearInbox();
      this.chatPanelService.getInbox();
    }
  }

  gotoChat(id, name) {
    this.chatMessageService.setName(name);
    this.navController.setDirection('root');
    this.router.navigate(['/chat/chat-user', id]);
  }

  chat() {
    this.router.navigateByUrl('/chat/chatlist');
  }

  more() {
    this.router.navigateByUrl('/dashboard/more');
  }

  service() {
    this.router.navigateByUrl('/dashboard/services');
  }

  home() {
    this.router.navigateByUrl('/dashboard/home');
  }

  getLoggedInUSerName(id) {
    this.chatSmeService
      .getSmeDetails(id)
      .pipe(first())
      .subscribe(smeData => {
        if (smeData.data && smeData.data.customerDetail) {
          this.smeName = smeData.data.customerDetail.customerName;
        } else if (smeData.data && smeData.data.profileDetail) {
          this.smeName = smeData.data.profileDetail.name;
        } else {
          this.smeName = 'unknown user';
        }
        this.chatPanelService.settoName(this.smeName);
      });
  }

  search() {
    this.navController.setDirection('root');
    this.router.navigateByUrl('/dashboard/search');
  }

  ngOnDestroy(): void {
    this.inboxSubscription.unsubscribe();
  }
}

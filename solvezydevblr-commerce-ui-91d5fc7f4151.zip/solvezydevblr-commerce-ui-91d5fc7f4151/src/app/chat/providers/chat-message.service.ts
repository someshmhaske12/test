import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

export class ChatMessage {
    userId: string;
    userName: string;
    toUserId: string;
    message: string;
    type?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ChatMessageService {
  private presenseSubject = new Subject<any>();
  private messageSubject = new Subject<any>();
  private composingSubject = new Subject<any>();
  private messageHistorySubject = new Subject<any>();
  private imageuploadedSubject = new Subject<any>();

  toJid: string = null;
  toName: string = null;


  constructor() { }

  sendPresence(message: string) {
    this.presenseSubject.next({ text: message });
  }

  getPresense(): Observable<any> {
    return this.presenseSubject.asObservable();
  }

  sendMessage(message: string) {
    this.messageSubject.next({ text: message });
  }

  getMessage(): Observable<any> {
    return this.messageSubject.asObservable();
  }

  sendComposing(message: string) {
    this.composingSubject.next({ text: message });
  }

  getComposing(): Observable<any> {
    return this.composingSubject.asObservable();
  }

  sendImageUploaded(message: string) {
    this.imageuploadedSubject.next({ text: message });
  }

  getImageUploaded(): Observable<any> {
    return this.imageuploadedSubject.asObservable();
  }

  getId() {
    return this.toJid;
  }

  setId(id) {
    this.toJid = id;
  }

  getName() {
    return this.toName;
  }

  setName(name) {
    this.toName = name;
  }

  getHistory() {
    return this.messageHistorySubject.asObservable();
  }

  sendHistory(msg: ChatMessage[]) {
    this.messageHistorySubject.next(msg);
  }
}

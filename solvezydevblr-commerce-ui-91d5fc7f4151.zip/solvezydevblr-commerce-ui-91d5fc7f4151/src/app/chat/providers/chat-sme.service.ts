import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/shared/common/common-service';

@Injectable({
  providedIn: 'root'
})
export class ChatSmeService {
  private smeProfileUrl = 'https://apis.solvezy.net/commerce/api/v1/profile?smeId=';
  constructor(private cs: CommonService) {}

  getSmeDetails(smeId) {
    return this.cs.api.get(this.smeProfileUrl + smeId, true);
  }
}

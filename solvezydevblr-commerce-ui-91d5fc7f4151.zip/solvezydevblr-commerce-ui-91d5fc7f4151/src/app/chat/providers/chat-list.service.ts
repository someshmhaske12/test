import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

export class InboxMessage {
  name?: string;
  id: string;
  image: string;
  msg: string;
  status?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ChatListService {
  smeDetailUrl = 'http://apis.solvezy.net/commerce/api/v1/profile?smeId=20c94460-4a65-4294-8ccb-2332e2e3bb39';

  private connectedSubject = new Subject<any>();
  private InboxCompletedSubject = new Subject<any>();

  private inbox: InboxMessage[] = [] as any;

  constructor() {}

  sendConnected(message: string) {
    this.connectedSubject.next({ text: message });
  }

  getConnected(): Observable<any> {
    return this.connectedSubject.asObservable();
  }

  sendInboxCompleted(message: string) {
    this.InboxCompletedSubject.next({ text: message });
  }

  getInboxCompleted(): Observable<any> {
    return this.InboxCompletedSubject.asObservable();
  }

  addMsgToInbox(id, msg) {
    const toAdd: InboxMessage = {} as any;

    toAdd.id = id.split('@')[0];
    toAdd.msg = msg;
    toAdd.image = 'assets/drawable/default-chat-icon.svg';

    this.inbox.push(toAdd);
  }

  getInbox() {
    return this.inbox;
  }

  clearInbox() {
    this.inbox = [];
  }
}

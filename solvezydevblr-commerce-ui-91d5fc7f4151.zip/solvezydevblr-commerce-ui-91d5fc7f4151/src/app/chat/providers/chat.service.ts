import { Injectable } from '@angular/core';
import { Strophe, $pres, $iq, $msg, $build } from 'strophe.js';
import * as $ from 'jquery';
import { ChatMessageService, ChatMessage } from './chat-message.service';
import { Subject, Observable } from 'rxjs';
import { ChatListService } from './chat-list.service';
import { environment } from 'src/environments/environment';

let chatPanelServiceInstance: any = null;

@Injectable({
  providedIn: 'root'
})
export class ChatPanelService {
  private connectedSubject = new Subject<any>();
  private inboxCompleteSubject = new Subject<any>();

  contacts: any[];
  chats: any[];
  user: any;
  client: any;
  host = 'localhost';
  jid: string;
  toJid: string;
  loggedInJid: string;

  connected = false;
  msgHistory: ChatMessage[] = []  as any;
  fromName: string;
  toName: string;


  private xmppConnectionsString = environment.url + '/chat-engine/http-bind'; // BOSH
  private xmppConnection: any = null;

  constructor(
    private chatMessageService: ChatMessageService,
    private chatListService: ChatListService) {
    chatPanelServiceInstance = this;
    // Strophe.log = (level: any, msg: string) => {
    //   console.log(level + ': ' + msg);
    // };

    // adding inbox to strophe
    Strophe.addConnectionPlugin('inbox', {
      _c: null,
      init(conn) {
        this._c = conn;
        Strophe.addNamespace('INBOX', 'erlang-solutions.com:xmpp:inbox:0');
      },
      query(options: any) {
        const _p = this._p;
        const attr = {
          type: 'set'
        };
        options = options || {};
        const inboxAttr: any = { xmlns: Strophe.NS.INBOX };
        if (!!options.queryid) {
          inboxAttr.queryid = options.queryid;
          delete options.queryid;
        }
        const iq = $iq(attr)
          .c('inbox', inboxAttr)
          .c('x', { xmlns: 'jabber:x:data', type: 'form' });

        iq.c('field', { var: 'FORM_TYPE', type: 'hidden' })
          .c('value')
          .t(Strophe.NS.INBOX)
          .up()
          .up();

        iq.up();

        const onMessage = options.onMessage;
        delete options.onMessage;
        const onComplete = options.onComplete;
        delete options.onComplete;
        // iq.cnode(new Strophe.RSM(options).toXML());

        const _c = this._c;
        const handler = _c.addHandler(
          onMessage,
          Strophe.NS.INBOX,
          'message',
          null
        );
        console.log('Sending Inbox');
        console.log(iq);
        return this._c.sendIQ(iq, function() {
          _c.deleteHandler(handler);
          onComplete.apply(this, arguments);
        });
      }
    });

    Strophe.addConnectionPlugin('http_upload', {
      _c: null,
      init(conn) {
        this._c = conn;
        Strophe.addNamespace('HTTP_UPLOAD', 'urn:xmpp:http:upload:0');
      },
      send(options) {
        const attr = {
          type: 'get',
          from: this._c.jid,
          to: 'upload.localhost'
        };

        // todo - call the image upload service

        const httpUploadAttr = {
          xmlns: Strophe.NS.HTTP_UPLOAD,
          'content-type': options.fileType,
          filename: options.fileName,
          size: options.fileSize
        };
        const iq = $iq(attr).c('request', httpUploadAttr);

        options.onSlot = (iq2) => {
          console.log(iq2);
          const put = $(iq2)
            .find('slot')
            .find('put')
            .attr('url');
          const get = $(iq2)
            .find('slot')
            .find('get')
            .attr('url');

          const xhr = new XMLHttpRequest();

          xhr.onreadystatechange = () => {
            if (xhr.readyState === 4) {
              console.log(get);
              const message = $msg({ to: options.receiver, type: 'chat' })
                .c('body')
                .t('<img src=\'' + get + '\' width=50 height=50></img>')
                .up()
                .c('active', {
                  xmlns: 'http://jabber.org/protocol/chatstates'
                });
              _c.send(message);
              chatPanelServiceInstance.chatMessageService.sendImageUploaded(get);
            } else {
              chatPanelServiceInstance.chatMessageService.sendImageUploaded('false');
            }
          };
          xhr.open('PUT', put, true);
          xhr.setRequestHeader('Content-type', options.fileType);
          xhr.send(options.file);
        };

        const _c = this._c;
        const handler = _c.addHandler(
          options.onSlot,
          Strophe.NS.HTTP_UPLOAD,
          null,
          null
        );
        return this._c.sendIQ(iq, () => {
          _c.deleteHandler(handler);
        });
      }
    });

    Strophe.addNamespace('RSM', 'http://jabber.org/protocol/rsm');

    Strophe.RSM = function(options) {
      this.attribs = [
        'max',
        'first',
        'last',
        'after',
        'before',
        'index',
        'count'
      ];

      if (typeof options.xml != 'undefined') {
        this.fromXMLElement(options.xml);
      } else {
        for (let ii = 0; ii < this.attribs.length; ii++) {
          let attrib = this.attribs[ii];
          this[attrib] = options[attrib];
        }
      }
    };

    Strophe.RSM.prototype = {
      toXML() {
        let xml = $build('set', { xmlns: Strophe.NS.RSM });
        for (let ii = 0; ii < this.attribs.length; ii++) {
          let attrib = this.attribs[ii];
          if (typeof this[attrib] != 'undefined') {
            xml = xml
              .c(attrib)
              .t(this[attrib].toString())
              .up();
          }
        }
        return xml.tree();
      },

      next(max) {
        let newSet = new Strophe.RSM({ max, after: this.last });
        return newSet;
      },

      previous(max) {
        let newSet = new Strophe.RSM({ max, before: this.first });
        return newSet;
      },

      fromXMLElement(xmlElement) {
        for (let ii = 0; ii < this.attribs.length; ii++) {
          let attrib = this.attribs[ii];
          let elem = xmlElement.getElementsByTagName(attrib)[0];
          if (typeof elem != 'undefined' && elem !== null) {
            this[attrib] = Strophe.getText(elem);
            if (attrib == 'first') {
              this.index = elem.getAttribute('index');
            }
          }
        }
      }
    };

    Strophe.addConnectionPlugin('mam', {
      _c: null,
      _p: ['with', 'start', 'end'],
      init(conn) {
        this._c = conn;
        Strophe.addNamespace('MAM', 'urn:xmpp:mam:2');
      },
      query(jid, options) {
        const _p = this._p;
        const attr = {
          type: 'set',
          to: jid 
        };
        options = options || {};
        const mamAttr: any = { xmlns: Strophe.NS.MAM };
        if (!!options.queryid) {
          mamAttr.queryid = options.queryid;
          delete options.queryid;
        }
        const iq = $iq(attr)
          .c('query', mamAttr)
          .c('x', { xmlns: 'jabber:x:data', type: 'submit' });

        iq.c('field', { var: 'FORM_TYPE', type: 'hidden' })
          .c('value')
          .t(Strophe.NS.MAM)
          .up()
          .up();
        let i;
        for (i = 0; i < this._p.length; i++) {
          const pn = _p[i];
          const p = options[pn];
          delete options[pn];
          if (!!p) {
            iq.c('field', { var: pn })
              .c('value')
              .t(p)
              .up()
              .up();
          }
        }
        iq.up();

        const onMessage = options.onMessage;
        delete options.onMessage;
        const onComplete = options.onComplete;
        delete options.onComplete;
        iq.cnode(new Strophe.RSM(options).toXML());

        const _c = this._c;
        const handler = _c.addHandler(
          onMessage,
          Strophe.NS.MAM,
          'message',
          null
        );
        console.log("coming");
        
        console.log(iq);
        
        return this._c.sendIQ(iq, function() {
          _c.deleteHandler(handler);
          onComplete.apply(this, arguments);
        });
      }
    });
  }

  login(jid: string, password = '12345'): void {
    // if (this.xmppConnection) {
    //   this.connectedSubject.next(true);
    //   return;
    // }

    if (!this.xmppConnection) {
      this.xmppConnection = new Strophe.Connection(this.xmppConnectionsString);
    }
    if (!this.connected) {
      this.jid = jid;
      this.xmppConnection.connect(
        jid + '@' + this.host,
        password,
        this.onConnect
      );
      this.loggedInJid = jid + '@' + this.host;
    }
    // this.xmppConnection.rawInput = (data: any) => {console.log("RAW IN: " + data)};
    // this.xmppConnection.rawOutput = (data: any) => {console.log("RAW OUT: " + data)};
  }

  logOut(): void {
    if (this.xmppConnection) {
      this.xmppConnection.options.sync = true;
      this.xmppConnection.flush();
      this.xmppConnection.disconnect('logout');
      this.xmppConnection = null;
    }
  }

  // helper to notify connected
  getConnected(): Observable<any> {
    return this.connectedSubject.asObservable();
  }

  getConnectedStatus() {
    return this.connected;
  }

  // helper to notify inbox completed
  getInboxCompleted(): Observable<any> {
    return this.inboxCompleteSubject.asObservable();
  }

  setToJid(toJid: string) {
    this.toJid = toJid;
  }

  setFromName(fromName) {
    this.fromName = fromName;
  }

  settoName(toName) {
    this.toName = toName;
  }

  sendMsg(msg: string) {
    // .c('text')  add node text
    const message = $msg({ to: this.toJid, type: 'chat' })
      .c('body')
      .t(msg)
      .up()
      .c('active', { xmlns: 'http://jabber.org/protocol/chatstates' });

    console.log('sending msg', msg , 'to', this.toJid);

    chatPanelServiceInstance.xmppConnection.send(message);
  }

  imageUpload(obj) {
    chatPanelServiceInstance.xmppConnection.http_upload.send(obj);
  }

  retrieveMsgs() {
    console.log('mam');
    chatPanelServiceInstance.msgHistory = [];
    chatPanelServiceInstance.xmppConnection.mam.query(
      chatPanelServiceInstance.jid + '@localhost',
      {
        with: this.toJid,
        // "max" : 10,
        before: '',
        onMessage(message) {
          console.log(message);

          const messageContent = $(message).find('message');
          const from = $(messageContent)
            .attr('from')
            .split('/')[0];
          const to = $(messageContent)
            .attr('to')
            .split('/')[0];
          const messageText = $(message)
            .find('body')
            .text();

          if((from == chatPanelServiceInstance.loggedInJid) && (to == chatPanelServiceInstance.toJid)) {
            let chatmsg: ChatMessage;
            if(messageText.includes('img')) {
              const src = chatPanelServiceInstance.extractImgSrc(messageText);
              console.log(src);
              chatmsg = {
                message: src,
                toUserId: to,
                userId: from,
                userName: chatPanelServiceInstance.fromName,
                type: 'img'
              };
            } else {
              chatmsg = {
                message: messageText,
                toUserId: to,
                userId: from,
                userName: chatPanelServiceInstance.fromName,
                type: 'text'
              };
            }
            // const chatmsg: ChatMessage = {
            //   message: messageText,
            //   toUserId: to,
            //   userId: from,
            //   userName: chatPanelServiceInstance.fromName
            // };
            chatPanelServiceInstance.msgHistory.push(chatmsg);
          } else if ((to == chatPanelServiceInstance.loggedInJid) && (from == chatPanelServiceInstance.toJid)) {
            let chatmsg: ChatMessage;
            if(messageText.includes('img')) {
              const src = chatPanelServiceInstance.extractImgSrc(messageText);
              console.log(src);
              chatmsg = {
                message: src,
                toUserId: to,
                userId: from,
                userName: chatPanelServiceInstance.toName,
                type: 'img'
              };
            } else {
              chatmsg = {
                message: messageText,
                toUserId: to,
                userId: from,
                userName: chatPanelServiceInstance.toName,
                type: 'text'
              };
            }
            // const chatmsg: ChatMessage = {
            //   message: messageText,
            //   toUserId: to,
            //   userId: from,
            //   userName: chatPanelServiceInstance.toName
            // };
            chatPanelServiceInstance.msgHistory.push(chatmsg);
          }

          return true;
        },
        onComplete(message) {
          console.log(message);
          chatPanelServiceInstance.chatMessageService.sendHistory(chatPanelServiceInstance.msgHistory);
        }
      }
    );
  }

  extractImgSrc(str) {
    const regex = /<img.*?src='(.*?)'/;
    const src = regex.exec(str)[1];
    return src;
  }

  getInbox() {
    console.log('Inbox called');
    if (chatPanelServiceInstance.xmppConnection) {
      chatPanelServiceInstance.xmppConnection.inbox.query({
        onMessage(message) {
          console.log('Inbox');
          console.log(message);
          let from = message.querySelector('message').getAttribute('from').split('/')[0];
          let to = message.querySelector('message').getAttribute('to').split('/')[0];
          let msgcontent = message.querySelector('message').textContent;

          if (msgcontent.includes('img')) {
            msgcontent = 'image';
          }

          let user = from != chatPanelServiceInstance.loggedInJid ? from : to;

          chatPanelServiceInstance.chatListService.addMsgToInbox(user, msgcontent);

          return true;
        },
        onComplete(message) {
          console.log('inbox on complete');
          console.log(message);
          chatPanelServiceInstance.inboxCompleteSubject.next(true);
        }
      });
    }
  }

  private onMessage(msg: any): boolean {
    console.log('on message');
    console.log(msg);
    const from = msg.getAttribute('from').split('/')[0];

    if(from == chatPanelServiceInstance.toJid){
      const composing = msg.querySelector('composing');
      if (composing) {
        chatPanelServiceInstance.chatMessageService.sendComposing('typing');
      }
      const body = msg.getElementsByTagName('body')[0];
      if (body) {
        chatPanelServiceInstance.chatMessageService.sendMessage(body);
      }
    }

    return true;
  }

  private onPresence(presence) {
    console.log('onpresense');
    console.log(presence);

    const ptype = $(presence).attr('type');
    const from = $(presence).attr('from');
    const jidId = chatPanelServiceInstance.jidToId(from);

    console.log(ptype);
    console.log(from);
    console.log(jidId);

    // if (ptype === 'subscribe') {
    //   // populate pending_subscriber, the approve-jid span, and
    //   // open the dialog
    //   // Gab.pending_subscriber = from;
    //   // $('#approve-jid').text(Strophe.getBareJidFromJid(from));
    //   // $('#approve_dialog').dialog('open');
    // } else if (ptype !== 'error') {
    //   // let contact = $('#roster-area li#' + jidId + ' .roster-contact')
    //   //   .removeClass('online')
    //   //   .removeClass('away')
    //   //   .removeClass('offline');
    //   if (ptype === 'unavailable') {
    //     // add offline
    //     console.log('offline');
    //   } else {
    //     let show = $(presence)
    //       .find('show')
    //       .text();
    //     if (show === '' || show === 'chat') {
    //       // online
    //       console.log('online');
    //     } else {
    //       // away
    //       console.log('away');
    //     }
    //   }

    //   // let li = contact.parent();
    //   // li.remove();
    //   // Gab.insert_contact(li);
    // }

    // reset addressing for user since their presence changed
    // $('#chat-' + jid_id).data('jid', Strophe.getBareJidFromJid(from));

    return true;
  }

  jidToId(jid: string) {
    return Strophe.getBareJidFromJid(jid)
      .replace(/@/g, '-')
      .replace(/\./g, '-');
  }

  private onConnect(status: any): void {
    switch (status) {
      case Strophe.Status.CONNECTING:
        console.log('Connecting to xmpp...');
        break;
      case Strophe.Status.CONNFAIL:
        chatPanelServiceInstance.connected = false;
        console.log('xmpp connection failed!');
        break;
      case Strophe.Status.DISCONNECTING:
        chatPanelServiceInstance.connected = false;
        console.log('Disconnecting from xmpp...');
        break;
      case Strophe.Status.DISCONNECTED:
        chatPanelServiceInstance.connected = false;
        console.log('Disconnected from xmpp');
        break;
      case Strophe.Status.CONNECTED:
        // We could have used 'this' instead of an external pointer (chatPanelServiceInstance),
        // but the compiler is getting the meaning of 'this' wrong since strophe.js is not a native TypeScript library.
        // This means that at run time 'this' doesn't point the service instance, rather to the connection itself.
        // In order to avoid confusion I've chosen to use an explicit pointer to the service.
        //
        chatPanelServiceInstance.connected = true;
        chatPanelServiceInstance.connectedSubject.next({ text: 'connected' });

        chatPanelServiceInstance.xmppConnection.addHandler(
          chatPanelServiceInstance.onMessage,
          null,
          'message',
          'chat'
        );

        // set up presence handler and send initial presence
        // chatPanelServiceInstance.xmppConnection.addHandler(
        //   chatPanelServiceInstance.onPresence,
        //   null,
        //   'presence'
        // );
        // Setting our presence in the server so that everyone can know that we are online
        chatPanelServiceInstance.xmppConnection.send($pres());

        console.log('xmpp connected!');
        break;
      case Strophe.Status.AUTHENTICATING:
        console.log('xmpp authenticating...');
        break;
      case Strophe.Status.AUTHFAIL:
        console.log('xmpp authentication failed!');
        chatPanelServiceInstance.connected = false;
        break;
      case Strophe.Status.ERROR:
        console.log('xmpp generic connection error!');
        chatPanelServiceInstance.connected = false;
        break;
      case Strophe.Status.ATTACHED:
        console.log('xmpp connection attached!');
        break;
      case Strophe.Status.REDIRECT:
        console.log('xmpp connection redirected!');
        break;
      case Strophe.Status.CONNTIMEOUT:
        console.log('xmpp connection timeout!');
        chatPanelServiceInstance.connected = false;
        break;
      default:
        console.log('xmpp: Unknow connection status');
        chatPanelServiceInstance.connected = false;
    }
  }
}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/shared/common/common-service'


@Injectable({
  providedIn: 'root',
})

export class ClientService {

  constructor(private http: HttpClient, private commonService: CommonService) { }

  postClientData(url, data, accessToken?) {
    if(accessToken) {
      const headers = new HttpHeaders({
        'accessToken': accessToken
      });
      const options = { headers };
      return this.http.post(url, data, options);
    } else  {
      return this.http.post(url, data);
    }
  }
/*
  postClientDatav2(url, data) {
    await let token = this.commonService.store.getAccessTokenFromLocalStorage();

      const headers = new HttpHeaders({
        'accessToken': token
      });
      const options = {headers};

  }*/
}

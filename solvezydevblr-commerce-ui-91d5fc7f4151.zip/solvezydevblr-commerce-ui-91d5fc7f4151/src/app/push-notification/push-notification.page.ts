import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-push-notification',
  templateUrl: './push-notification.page.html',
  styleUrls: ['./push-notification.page.scss'],
})
export class PushNotificationPage implements OnInit {

  constructor(private route: ActivatedRoute) { 
    alert("Routed to push notification display page :"+this.route.params);
 }

  ngOnInit() {
  }

}

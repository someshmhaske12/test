import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { FCM } from '@ionic-native/fcm/ngx';
// import { Router } from '@angular/router';
import { CommonService } from './shared/common/common-service';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private screenOrientation: ScreenOrientation,
    private router: Router,
    private fcm: FCM,
    private commonService: CommonService,
    private notifyServie: NotifyService
  ) {
    this.initializeApp();
  }

  initializeApp() {
    //TODO update resume login
    //CLEARING PREVIOUS LOCAL STORAGE DATA
    this.commonService.store.clearLocalStorage();
    // REDIRECTING TO LOGIN PAGE
    this.router.navigateByUrl("/");

    if (this.platform.is('cordova')) {
      this.platform.ready().then(() => {
        this.screenOrientation.lock(
          this.screenOrientation.ORIENTATIONS.PORTRAIT_PRIMARY
        );
        // On notification
        this.fcm.onNotification().subscribe(data => {
          //console.log("prady");
          console.log(data);
          if(data.wasTapped) {
            console.log(data.wasTapped);
          } else {
            this.notifyServie.showToast(data.body);
          }
        });
       });
    }

    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });

    
  }
}

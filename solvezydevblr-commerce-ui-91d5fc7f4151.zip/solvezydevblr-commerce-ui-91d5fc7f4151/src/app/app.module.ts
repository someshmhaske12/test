import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { IonicModule } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { IonicStorageModule } from '@ionic/storage';
import { Camera } from '@ionic-native/camera/ngx';
import { Base64 } from '@ionic-native/base64/ngx';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { MaterialCustomModule } from './shared/material-custom/material-custom.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { AppCommonModule } from './shared/common/app-common.module';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { CustomReuseStrategy } from './customreuse-strategy';
import { File } from '@ionic-native/file/ngx';
import { FCM } from '@ionic-native/fcm/ngx';
import { Device } from '@ionic-native/device/ngx';

@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [
    BrowserModule,
    IonicModule.forRoot({
      scrollAssist: true,
      hardwareBackButton: false
    }),
    IonicStorageModule.forRoot(),
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialCustomModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppCommonModule
  ],
  providers: [
    StatusBar,
    SplashScreen,
    InAppBrowser,
    ScreenOrientation,
    File,
    Base64,
    FCM,
    Device,
    { provide: RouteReuseStrategy, useClass: CustomReuseStrategy },
    Camera
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

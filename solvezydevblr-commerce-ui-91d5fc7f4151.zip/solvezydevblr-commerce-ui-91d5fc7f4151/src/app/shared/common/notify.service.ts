import { Injectable, NgZone, Component } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { LoadingController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class NotifyService {
  loader: any;
  constructor(
    public snackBar: MatSnackBar,
    private zone: NgZone,
    public loadingController: LoadingController
  ) {}

  public showToast(message, action = 'Dismiss', duration = 3000) {
    this.snackBar.open(message, action, { duration });
  }

  public notificationWithClassAndAction(message: string, action: string, className: string,  duration = 3000){
    this.snackBar.open(message, action, {
      duration,
      panelClass: [className]
    }); 
  }

  public async createLoader(message = 'Please wait...') {
    if (this.loader) {
      this.loader.dismiss();
    }
    this.loader = await this.loadingController.create({
      spinner: 'circles',
      duration: 8000,
      message,
      translucent: true
    });

    await this.loader.present();

    const { role, data } = await this.loader.onDidDismiss();

    // this.loader.onDidDismiss(() => {
    //   this.loader = null;
    // });
  }

  public dismissLoader() {
    if (this.loader) {
      this.loader.dismiss();
    }
  }

  public notifyAutoDismissal(message:string) {
    this.snackBar.open(message, 'Undo', {
        duration: 3000
    });
  }

}

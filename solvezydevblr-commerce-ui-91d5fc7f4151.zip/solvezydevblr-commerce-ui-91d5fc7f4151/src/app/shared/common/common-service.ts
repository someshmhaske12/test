
import { Injectable } from '@angular/core';
import { ApiService } from './api-service';
import { StorageService } from './storage-service';

@Injectable({
    providedIn: 'root'
  })
export class CommonService {
    constructor(public api: ApiService, public store: StorageService) {}
}

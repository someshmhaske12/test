
 import { Injectable } from '@angular/core';
 import { UserProfile, CustomerDetails, Product } from 'src/app/user-profile/model/user-profile-models';

 @Injectable({
     providedIn: 'root'
   })
 export class AppCommonDataModel {

     userProfile: UserProfile = {} as any;
     // TODO create structure
     customerDetail: CustomerDetails = {} as any;
     recommondedSmeProfile: UserProfile = [] as any;
     productList: Map<string, Product[]> = new Map<string, Product[]>();

     constructor() {}


     setProducts(products: Array<any>) {
       for (const product of products) {
         const smeId = product['smeId'];
         if (smeId == null) {
            continue;
         }
         if (this.productList.get(smeId) == null) {
             this.productList.set(smeId, []);
          }
         this.productList.get(smeId).push(product);
       }
     }
     getProducts(smeId: string) {
       return this.productList.get(smeId) != null ? this.productList.get(smeId) : [];
     }

 }

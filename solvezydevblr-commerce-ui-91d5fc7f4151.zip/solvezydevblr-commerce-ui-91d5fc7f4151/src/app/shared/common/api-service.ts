import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { NotifyService } from './notify.service';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private static CONTENT_TYPE_KEY = 'Content-Type';
  private static DEFAULT_CONTENT_TYPE = 'application/json; charset=utf-8';

  constructor(
    private httpClient: HttpClient,
    private notifyService: NotifyService
  ) {}

  postWithHeaders(
    url: string,
    data: any,
    headers: any,
    notifyOnError?: boolean
  ): Observable<any> {
    return this.postRequest(url, data, headers, notifyOnError);
  }

  post(url: string, data: any, notifyOnError?: boolean): Observable<any> {
    return this.postRequest(url, data, null, notifyOnError);
  }

  postWitNoBody(url: string, notifyOnError?: boolean): Observable<any> {
    return this.postRequest(url, null, null, notifyOnError);
  }

  putWithHeaders(
    url: string,
    data: any,
    headers: any,
    notifyOnError?: boolean
  ): Observable<any> {
    return this.putRequest(url, data, headers, notifyOnError);
  }

  put(url: string, data: any, notifyOnError?: boolean): Observable<any> {
    return this.putRequest(url, data, null, notifyOnError);
  }

  putWithNoBody(url: string, notifyOnError?: boolean): Observable<any> {
    return this.putRequest(url, null, null, notifyOnError);
  }

  getWithHeaders(
    url: string,
    headers: any,
    notifyOnError?: boolean
  ): Observable<any> {
    return this.getRequest(url, headers, notifyOnError);
  }

  get(url: string, notifyOnError?: boolean): Observable<any> {
    return this.getRequest(url, null, notifyOnError);
  }

  getWithTextResponse(url: string, notifyOnError?: boolean): Observable<any> {
    return this.httpClient
      .get<any>(url, {
        headers: this.buildHeaders(null),
        responseType: 'text' as 'json'
      })
      .pipe(catchError(errResp => this.handleError(errResp, notifyOnError)));
  }

  deleteWithHeaders(
    url: string,
    headers: any,
    notifyOnError?: boolean
  ): Observable<any> {
    return this.deleteRequest(url, headers, notifyOnError);
  }

  delete(url: string, notifyOnError?: boolean): Observable<any> {
    return this.deleteRequest(url, null, notifyOnError);
  }

  private postRequest(
    url: string,
    data: any,
    headers: JSON,
    notifyOnError?: boolean
  ): Observable<any> {
    return this.httpClient
      .post<any>(url, data, { headers: this.buildHeaders(headers) })
      .pipe(catchError(errResp => this.handleError(errResp, notifyOnError)));
  }

  private getRequest(
    url: string,
    headers: JSON,
    notifyOnError?: boolean
  ): Observable<any> {
    return this.httpClient
      .get<any>(url, { headers: this.buildHeaders(headers) })
      .pipe(catchError(errResp => this.handleError(errResp, notifyOnError)));
  }

  private putRequest(
    url: string,
    data: any,
    headers: JSON,
    notifyOnError?: boolean
  ): Observable<any> {
    return this.httpClient
      .put<any>(url, data, { headers: this.buildHeaders(headers) })
      .pipe(catchError(errResp => this.handleError(errResp, notifyOnError)));
  }

  private deleteRequest(
    url: string,
    headers: JSON,
    notifyOnError?: boolean
  ): Observable<any> {
    return this.httpClient
      .delete<any>(url, { headers: this.buildHeaders(headers) })
      .pipe(catchError(errResp => this.handleError(errResp, notifyOnError)));
  }

  private buildHeaders(headers: JSON): HttpHeaders {
    const keyValues: any = {};
    keyValues[ApiService.CONTENT_TYPE_KEY] = ApiService.DEFAULT_CONTENT_TYPE;
    if (headers) {
      for (const key in headers) {
        if (headers.hasOwnProperty(key)) {
          keyValues[key] = headers[key];
        }
      }
    }
    return new HttpHeaders(keyValues);
  }

  private handleError(error: HttpErrorResponse, notify: boolean) {
    let message = null;
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred.
      (message = 'Unable to complete the reqest. Error :'), error.error.message;
      console.error(message);
    } else {
      // Server side failure
      message = `Something went wrong! Status : ${error.status}, Error : ${error.error}`;
      console.error(message);
    }
    // return an observable with a user-friendly error message
    if (notify) {
      this.notifyService.showToast(message, 'error');
    }
    return throwError(message);
  }
}

import { Injectable } from '@angular/core';
import { Platform } from '@ionic/angular';
import { Device } from '@ionic-native/device/ngx';
import { environment } from 'src/environments/environment';
import { CommonService } from './common-service';
import { FCM } from '@ionic-native/fcm/ngx';

@Injectable({
  providedIn: 'root'
})
export class FcmService {
  token: any;
  sendTokenUrl = environment.url + '/alert-notification/api/v1/device';
  constructor(
    private device: Device,
    private fcm: FCM,
    private cs: CommonService,
    private platform: Platform
  ) {
    if (this.platform.is('cordova')) {
      this.intitialize();
    }
  }

  private intitialize() {
    // GET token
    this.fcm.getToken().then(token => {
        this.token = token;
    });

    this.fcm.onTokenRefresh().subscribe(token => {
        this.token = token;
    });

    // Subscribe to topic
    this.fcm.subscribeToTopic('sme-onboard').then(
      success => {
        console.log('Successfully subscribed to sem-onboard topic', 'close');
      },
      err => {
        console.log('Unable subscribed to sem-onboard topic', 'close');
      }
    );
  }

  public sendToken(mobileNumber: string) {
    if (this.platform.is('cordova')) {
      const body = {
        active: true,
        deviceId: this.device.uuid,
        fcmToken: this.token,
        manufacturerName: this.device.manufacturer,
        modelName: this.device.model,
        operatingSystem: this.device.platform,
        userId: '+91' + mobileNumber
      };

      this.cs.api.post(this.sendTokenUrl, body).subscribe();
    }
  }
}

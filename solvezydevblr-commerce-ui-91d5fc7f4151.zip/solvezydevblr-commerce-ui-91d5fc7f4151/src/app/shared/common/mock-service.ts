import { Injectable } from '@angular/core';
import { UserProfile, CustomerDetails } from 'src/app/user-profile/model/user-profile-models';

@Injectable({
    providedIn:"root"
})
export class MockService{

    getMockUserProfile():UserProfile{
        return {} as any;
    }

    getMockCustomerDetail():CustomerDetails{
        return {} as any;
    }

}
import { Base64 } from '@ionic-native/base64/ngx';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { Observable, Observer } from 'rxjs';
import { NotifyService } from './notify.service';
import { CommonService } from './common-service';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class SnapShotUploaderService {

    private docUploadBase64Url: string = "https://apis.solvezy.net/commerce/api/v1/upload-document-base64";


    constructor(private camera: Camera,
        private base64: Base64,
        private notifyService: NotifyService,
        private _c: CommonService) { }

    public uploadPicFromCamera(docType: string): Observable<any> {
        const uploadPicObserver = Observable.create((observer: Observer<any>) => {
            this.takeBase64Pic().subscribe(
                result => {
                    this.uploadDocument(result.base64File, result.url.substring(result.url.lastIndexOf("/") + 1, result.url.length), docType).subscribe(
                        success => {
                            if (success != null && success["data"] != null) {
                                success["data"]["localUrl"] = result.url;
                                observer.next(success["data"]);
                                observer.complete();
                            } else {
                                observer.error("Unable to complete the task");
                            }
                        },
                        error => {
                            observer.error("Unable to complete the task");
                        }
                    )
                },
                error => {
                    observer.error("Unable to complete the task");
                }
            );
        });
        return uploadPicObserver;
    }

    private takeBase64Pic(): Observable<any> {
        console.log("Camera about to open");
        const options: CameraOptions = {
            quality: 10,
            destinationType: this.camera.DestinationType.FILE_URI,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        }
        const cameraObserver = Observable.create((observer: Observer<any>) => {
            this.camera.getPicture(options).then((imageData) => {
                console.log("Image had taken successfully", imageData);
                this.base64.encodeFile(imageData).then((base64File: string) => {
                    let imgUrl = (<any>window).Ionic.WebView.convertFileSrc(imageData);
                    observer.next({ "base64File": base64File, "url": imgUrl });
                    observer.complete();
                }, (err) => {
                    // Handle error
                    this.notifyService.showToast("Unable to take the picture");
                    observer.error("Unable to take the picture");
                });
            }).catch(error => {
                // Handle error
                this.notifyService.showToast("Unable to take the picture");
                observer.error("Unable to take the picture");
            });
        });
        return cameraObserver;
    }

    uploadDocument(base64File: string, docName: string, docType: string) {
        return this._c.api.postWithHeaders(this.docUploadBase64Url, { "file": encodeURIComponent(base64File), "fileName": docName }, { "DOCUMENT_TYPE": docType });
    }

}

import { NgModule } from '@angular/core';
import { NumberOnlyDirective } from './number-only.directive';
import { NgOtpInputModule } from 'ng-otp-input';


@NgModule({
  declarations: [NumberOnlyDirective],
  imports: [NgOtpInputModule],
  exports: [
    NumberOnlyDirective,
    NgOtpInputModule
  ]
})
export class AppCommonModule { }

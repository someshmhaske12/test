
import { AppCommonDataModel } from './app-common.datamodel';
import { CommonService } from './common-service';
import { NgZone, Injectable } from '@angular/core';
import { NotifyService } from './notify.service';

@Injectable({
    providedIn: 'root'
})
export class CommonUserProfileService {
    // TODO move to environments
    profileUrl = 'https://apis.solvezy.net/commerce/api/v1/profile?smeId=';

    constructor(private _dm: AppCommonDataModel,
                private _c: CommonService,
                private ngZone: NgZone,
                private notifyService: NotifyService) {

    }
    public updateUerProfile(smeId?: string) {
        if (smeId != null) {
        this.fetchDataForSmeId(smeId);
        return;
        }
        this._c.store.getSmeId().then(id => {
            if (id == null) {
                this.notifyService.showToast('Unable to load user details', 'close');
                return;
            }
            console.log('Updating data for smeId : ' + id);
            smeId = id;
            this.fetchDataForSmeId(smeId);
        });
    }

    private fetchDataForSmeId(smeId: string) {
        this._c.api.get(this.profileUrl + smeId, true).subscribe(
            response => {
            if (response != null && response.data != null && response.data.profileDetail != null) {
            this.ngZone.run(r => {
                this._dm.userProfile = response.data.profileDetail;
            });
            }
            }
        );
    }
}

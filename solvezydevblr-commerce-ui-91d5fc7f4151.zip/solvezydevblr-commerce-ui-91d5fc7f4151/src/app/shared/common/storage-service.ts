import { Storage } from '@ionic/storage';
import { Injectable } from '@angular/core';
import * as _ from "lodash";

@Injectable({
    providedIn: 'root'
})

export class StorageService {
    phoneNumKey = 'number';
    smeIdKey = 'smeId';
    accessTokenKey = 'accessToken';
    refreshTokenKey = 'refreshToken';
    solvIdKey = 'solvId';
    constructor(private store: Storage) {}
    setUserPhoneNum(phoneNum: string) {
        if(_.startsWith(phoneNum, '+91')) {
            phoneNum = phoneNum.substring(3);
        }
        this.store.set(this.phoneNumKey, phoneNum);
        this.getUserPhoneNumber().then((num) => {

        });
    }
    getUserPhoneNumber() {
        this.store.get(this.phoneNumKey).then((num) => {
        });
        return this.store.get(this.phoneNumKey);
    }

    setSmeId(smeId: string) {
        return this.store.set(this.smeIdKey, smeId).then((id) => {
                console.log('Set SMEId:', id);
            });
    }

    getSmeId() {
        return this.store.get('smeId');
    }

    // TO-DO Store this in browser cookie
    setAccessTokenToLocalStorage(accessToken: string) {
        this.store.set(this.accessTokenKey, accessToken);
    }

    getAccessToken() {
        return this.store.get(this.accessTokenKey);
    }

    setRefreshToken(refreshToken:string){
        this.store.set(this.refreshTokenKey, refreshToken);
    }

    getRefreshToken(){
        return this.store.get(this.refreshTokenKey);
    }

    setSolvId(solvId: string) {
        this.store.set(this.solvIdKey, solvId);
    }

    getSolvId() {
        return this.store.get(this.solvIdKey);
    }

    clearLocalStorage(){
        this.store.clear();
        console.log("CLEARED PREVIOUS LOCAL STORAGE");
    }
}
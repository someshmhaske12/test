import { NgModule } from '@angular/core';
import {
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatCheckboxModule,
  MatDialogModule,
  MatRadioModule,
  MatSnackBarModule,
  MatExpansionModule,
  MatCardModule,
  MatSelectModule,
  MatProgressBarModule,
  MatIconModule,
  MatListModule,
  MatBottomSheetModule,
  MatTabsModule
} from '@angular/material';

const MaterialComponentsUsed = [
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatCheckboxModule,
  MatDialogModule,
  MatRadioModule,
  MatSnackBarModule,
  MatExpansionModule,
  MatCardModule,
  MatSelectModule,
  MatProgressBarModule,
  MatIconModule,
  MatListModule,
  MatBottomSheetModule,
  MatTabsModule
];

@NgModule({
  imports: [MaterialComponentsUsed],
  exports: [MaterialComponentsUsed]
})
export class MaterialCustomModule {}

import { Component, OnInit } from '@angular/core';
import { CameraOptions, Camera } from '@ionic-native/camera/ngx';
import { OnboardingService } from 'src/app/user-onboarding/onboarding.service';

@Component({
  selector: 'app-factory-image',
  templateUrl: './factory-image.component.html',
  styleUrls: ['./factory-image.component.scss'],
})
export class FactoryImageComponent implements OnInit {

  constructor(private camera: Camera,private onboardingService:OnboardingService) { }
  public photos: Photo[] = [];
  options: CameraOptions = {
    quality: 100,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    correctOrientation: true,
    sourceType: 1
  };
  ngOnInit() { }
  takePicture() {
    this.options.sourceType = 1;
    this.camera.getPicture(this.options).then((imageData) => {
      this.photos.unshift({
        data: 'data:image/jpeg;base64,' + imageData
      });
    }, (err) => {
      console.log("Camera issue: " + err);
    });
  }
  uploadFromGallery() {
    this.options.sourceType = 0;
    this.camera.getPicture(this.options).then((imageData) => {
      this.photos.unshift({
        data: 'data:image/jpeg;base64,' + imageData
      })
    }, (err) => {
      console.log("Camera issue:" + err);
    });
  }
  back() {
    this.onboardingService.backClicked();
  }
}
class Photo {
  data: any;
}
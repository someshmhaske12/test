import { Component, OnInit, Inject} from '@angular/core';
import {FormBuilder, FormGroup, FormControl, Validators} from '@angular/forms';
import { UserProfileService } from '../../user-profile.service';
import { BankDetail } from '../../model/user-profile-models';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { ProfileScreenComponent } from '../profile-screen.component';

@Component({
  selector: 'app-add-bankdetails',
  templateUrl: './add-bankdetails.component.html',
  styleUrls: ['./add-bankdetails.component.scss'],
})
export class AddBankdetailsComponent implements OnInit  {
  // docs: any[] = [
  //   { value: 'ESTABLISHMENT_LICENSE', viewValue: 'HDFC' },
  //   { value: 'UDYOG_AADHAAR', viewValue: 'SBI' },
  //   { value: 'TRADE_LICENSE', viewValue: 'Axis Bank' },
  //   { value: 'FSSAI_REG', viewValue: 'Kotak Mahindra Bank' }
  // ];

  bankForm: FormGroup;
  banks = [
    { id: 'Airtel', clientName: 'Airtel Payments Bank'},
    { id: 'Allahabad', clientName: 'Allahabad Bank'},
    { id: 'Andhra', clientName: 'Andhra Bank'},
    { id: 'Axis', clientName: 'Axis Bank'},
    { id: 'Bandhan', clientName: 'Bandhan Bank'},
    { id: 'Baroda', clientName: ' Bank of Baroda'},
    { id: 'India', clientName: 'Bank of India'},
    { id: 'Maharashtra', clientName: 'Bank of Maharashtra'},
    { id: 'Canara', clientName: 'Canara Bank'},
    { id: 'Central', clientName: 'Central Bank of India'},
    { id: 'Dena', clientName: 'Dena Bank'},
    { id: 'Deutsche', clientName: 'Deutsche Bank'},
    { id: 'Dhanlakshmi', clientName: 'Dhanlakshmi Bank'},
    { id: 'Federal', clientName: 'Federal Bank'},
    { id: 'HDFC', clientName: 'HDFC Bank'},
    { id: 'ICICI', clientName: 'ICICI Bank'},
    { id: 'IDBI', clientName: 'IDBI Bank'},
    { id: 'IDFC', clientName: 'IDFC First Bank'},
    { id: 'Indian', clientName: 'Indian Bank'},
    { id: 'overseas', clientName: 'Indian overseas Bank'},
    { id: 'Induslnd', clientName: 'Induslnd Bank'},
    { id: 'Jammu', clientName: 'Jammu & Kashmir Bank'},
    { id: 'Kotak', clientName: 'Kotak Bank'},
    { id: 'Oriental', clientName: 'Oriental Bank of Commerce'},
    { id: 'Punjab', clientName: 'Punjab National Bank'},
    { id: 'South', clientName: 'South Indian Bank'},
    { id: 'Standard', clientName: 'Standard Chartered Bank'},
    { id: 'State', clientName: 'State Bank of India'},
    { id: 'Syndicate', clientName: 'Syndicate Bank'},
    { id: 'royal', clientName: 'The royal bank of Scotland'},
    { id: 'Union', clientName: 'Union Bank of India'},
    { id: 'United', clientName: 'United Bank of India'},
    { id: 'Vijaya', clientName: 'Vijaya Bank'},
    { id: 'Yes', clientName: 'Yes Bank Ltd'}
  ];

  constructor(private bottomSheetRef: MatBottomSheetRef<ProfileScreenComponent>,
              @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
              private formBuilder: FormBuilder, 
              private userProfile:UserProfileService,
              private notifyService:NotifyService) { }

  ngOnInit(){
    console.log(this.banks, 'id');
    this.bankForm = this.formBuilder.group({
      selectedBank : new FormControl('', Validators.required),
      acountHolder: new FormControl('', [Validators.required]),
      accountNumber: new FormControl('', Validators.required),
      ifscCode: new FormControl('', Validators.required)
    });
  }
  getbankDetails(e) {
    console.log(e.target)
  }

  cross(){
    this.bottomSheetRef.dismiss(); 
  }


  onBankFormSubmit(){
    console.log(this.bankForm, 'acountHolder');
    let bankdetails:BankDetail = {} as any;
    bankdetails.IFSC = this.bankForm.value.ifscCode;
    bankdetails.accountHolder = this.bankForm.value.accountHolder;
    bankdetails.accoutNumber = this.bankForm.value.accountNumber;
    bankdetails.name = this.bankForm.value.selectedBank;
    // bankdetails.name = this.getBankName(this.bankForm.value.selectedBank);
    this.userProfile.updateBankDetails(bankdetails).subscribe(
      success=>{
        //TODO on success
        this.notifyService.showToast("Updated bank details!","close");
      }
    );
  }

  getBankName(id:string){
    for(let bank of this.banks){
      if(bank.id == id){
        return bank.clientName;
      }
    }
    return null;
  }
}

import { Component, OnInit, Inject } from '@angular/core';
import {FormBuilder,FormGroup, FormControl,Validators} from '@angular/forms';
import { UserProfileService } from '../../user-profile.service';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { ProfileScreenComponent } from '../profile-screen.component';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { AppCommonDataModel } from 'src/app/shared/common/app-common.datamodel';

@Component({
  selector: 'app-add-designation',
  templateUrl: './add-designation.component.html',
  styleUrls: ['./add-designation.component.scss'],
})
export class AddDesignationComponent implements OnInit{

  userDesignation="";

  constructor(private bottomSheetRef: MatBottomSheetRef<ProfileScreenComponent>,
               @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
               private formBuilder: FormBuilder,
               private userProfileService: UserProfileService,
               private notifyService:NotifyService,
               private datamodel: AppCommonDataModel
               ) {
                 this.updatePreviousData();
                }

  designationForm = this.formBuilder.group({
    designation : new FormControl('', Validators.required)
  });

  ngOnInit(){
    this.updatePreviousData();
  }

  updatePreviousData(){
    if(this.datamodel.userProfile!=null && this.datamodel.userProfile.designation!=null){
      this.userDesignation = this.datamodel.userProfile.designation;
     }
  }

  cross(){
    this.bottomSheetRef.dismiss(); 
  }

  onDesignationForm(){
    console.log(this.designationForm, 'designation'); 
    this.userProfileService.updateDesignation(this.designationForm.value.designation).subscribe(
      success=>{
        //TODO on success 
        this.datamodel.userProfile.designation = this.designationForm.value.designation;
        this.notifyService.showToast("Designation successfully updated!");
        this.bottomSheetRef.dismiss();
      }
    );
  }

}

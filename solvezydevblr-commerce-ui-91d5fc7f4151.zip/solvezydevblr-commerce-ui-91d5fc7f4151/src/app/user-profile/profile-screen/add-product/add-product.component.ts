import { Component, OnInit, ElementRef, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray} from '@angular/forms';
import { UserProfileService } from '../../user-profile.service';
import { Product , ProductAdded} from '../../model/user-profile-models';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { OnboardingService } from '../../../user-onboarding/onboarding.service';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { ProfileScreenComponent } from '../profile-screen.component';
import { CommonService } from 'src/app/shared/common/common-service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss'],
})
export class AddProductComponent implements OnInit {
  @ViewChild('input', {static: true}) input: ElementRef;
  @ViewChild('productform', { static: true }) form;
  // @ViewChild('input', { static: true }) input;
  files: any;
  otpFailedFlag = false;
  setGreenTick = false;
  submitFlag = false;
  addCounter = 0;
  imgURL: string  | ArrayBuffer;
  toshow: any;
  docs: any[] = [
    { value: 'Mobile_Accessories', viewValue: 'Mobile accessories' },
    { value: 'Audio_Devices', viewValue: 'Audio devices' },
    { value: 'Camera_And_Accessories', viewValue: 'Camera and accessories' },
    { value: 'Mobile_Phones', viewValue: 'Mobile phones' },
    { value: 'Tablet', viewValue: 'Tablets' }
  ];

  productForm: FormGroup;
  items: FormArray;
  addedProducts: Product[] = [] as any;


  constructor( private bottomSheetRef: MatBottomSheetRef<ProfileScreenComponent>,
               @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
               private formBuilder: FormBuilder,
               private profileService: UserProfileService,
               private onboardingService: OnboardingService,
               private notifyService: NotifyService,
               private camera: Camera,
               private _c:CommonService) {
                 }
               ngOnInit() {
                  this.productForm = this.formBuilder.group({
                    // productImages : new FormControl(''),
                    selectedcategory : new FormControl('', [Validators.required]),
                    productName: new FormControl('', [Validators.required]),
                    productDescription: new FormControl('', [Validators.required]),
                    price: new FormControl(''),
                    weight: new FormControl(''),
                    size: new FormControl(''),
                    minimumOrder: new FormControl(''),
                    tags: new FormControl('', [Validators.required]),
                    // items: this.formBuilder.array([ this.createItem() ])
                  });
                }

                cross() {
                  this.bottomSheetRef.dismiss();
                }

  openGalery(event): void {
    this.files = event.target.files[0];
    this.imageDoc(event.target.files[0]);
  }
  imageDoc(files) {
    console.log(files);
    this.notifyService.createLoader();
    this.onboardingService.addproductImg(files)
      .subscribe(
        (img: any) => {
          this.toshow = img.data.key;
          this.imgURL = this.onboardingService.getImageUrl(this.toshow);
          console.log(this.imgURL);
          this.form.resetForm();
          // this.onboardingService.galleryClicked.emit(img);

          this.notifyService.dismissLoader();
          this.notifyService.showToast('Image uploaded successfully');
          this.otpFailedFlag = true;
        },
        err => {
          this.otpFailedFlag = true;
          console.log('errerr');
          console.log(err);
        }
      );
  }

  onFormSubmit(){
    this._c.store.getSmeId().then(smeId=>{
      this.productUploading(smeId);
    });
  }

private productUploading(smeId: string) {
    this.addCounter++;
    this.submitFlag = true;
    console.log(this.productForm, 'productName');
    const product: Product = {} as any;
    const values = this.productForm.value;
    product.category = values.selectedcategory;
    product.description = values.productDescription;
    product.title = values.productName;
    product.unitPrice = values.price;
    product.smeId = smeId;
    // TODO not implemented at service side
    product.size = values.size;
    product.minOrderQty = values.minimumOrder;
    product.tags = [values.tags];
    product.imageId = this.toshow;
    this.profileService.createProduct(product).subscribe(
      success => {
        console.log(success);

        this.imgURL = this.onboardingService.getImageUrl(product.imageId);
        console.log(this.imgURL);
        // changing image url and pushing
        product.imageId = this.imgURL;
        this.addedProducts.push(product);
        this.form.resetForm();
        this.imgURL = null;
      }
    );
  }
}

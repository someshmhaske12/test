import { Component, OnInit, ElementRef, Inject, ViewChild, NgZone } from '@angular/core';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { OnboardingService } from '../../../user-onboarding/onboarding.service';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { ProfileScreenComponent } from '../profile-screen.component';
import { FormGroup } from '@angular/forms';
import { AppCommonDataModel } from 'src/app/shared/common/app-common.datamodel';
import { UserProfileService } from '../../user-profile.service';
import { SnapShotUploaderService } from 'src/app/shared/common/snap-shot-uploader.service';


@Component({
  selector: 'app-add-factory-images',
  templateUrl: './add-factory-images.component.html',
  styleUrls: ['./add-factory-images.component.scss'],
})
export class AddFactoryImagesComponent implements OnInit {
  @ViewChild('productform', { static: true }) form;
  @ViewChild('input', { static: true }) input: ElementRef;

  otpFailedFlag = false;
  productForm: FormGroup;
  factoryImages = [];
  imageKeys = {};


  constructor(private bottomSheetRef: MatBottomSheetRef<ProfileScreenComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private onboardingService: OnboardingService,
    private notifyService: NotifyService,
    private _dm: AppCommonDataModel,
    private userPforileService: UserProfileService,
    private snapShotUploaderService:SnapShotUploaderService,
    private ngZone:NgZone) { }

  ngOnInit() {
    this.imageKeys = {};
    if (this._dm.userProfile != null && this._dm.userProfile.factory != null) {
      this.factoryImages = this._dm.userProfile.factory;
    }
    this.udateImgList();
  }

  cross() {
    this.bottomSheetRef.dismiss();
  }

  openCamera($event: any) {
    this.snapShotUploaderService.uploadPicFromCamera("FACTORY").subscribe(
      result=>{
        this.ngZone.run(r=>{
          $event.target.src = result["localUrl"];
        });
        console.log("Temp url updated to factory image node :"+result["localUrl"]);
        this.imageKeys[$event.target.id] = {"filekey":result["key"], "bucketName":result["bucket"]};
      },
      error=>{

      }
    );
  }

  submit() {
    let images = [];
    for (let key in this.imageKeys) {
      images.push(this.imageKeys[key]);
    }
    if (images.length == 0) {
      console.log("No images added");
      return;
    }
    this.userPforileService.updateFactoryImages(images).subscribe(response=>{
      this.notifyService.showToast("Images uploaded successfully");
      if(response != null && response["data"]!=null&&response["data"]["profileDetail"]!=null&&response["data"]["profileDetail"]["factory"]!=null){
        this._dm.userProfile.factory = response["data"]["profileDetail"]["factory"];
      }
    });
    console.log("uploaded images successfully");
  }

  uploadFile(fileBase64, imgId: string) {
    this.onboardingService.addFactory(fileBase64)
      .subscribe(
        (doc: any) => {
          console.log(doc);
          this.notifyService.showToast('Image uploaded successfully');
          this.imageKeys[imgId] = { "filekey": doc.data.key, "bucketName": doc.data.bucket };
        }, err => {
          console.warn("Unable to uploading images :", fileBase64);
        });
  }

  private udateImgList() {
    let size = (this.factoryImages == null || this.factoryImages.length == 0) ? 4 : 4 - this.factoryImages.length;
    for (let i = size; i > 0; i--) {
      if (this.factoryImages == null) {
        this.factoryImages = [];
      }
      this.factoryImages.push({ filekey: "assets/icon/profile/add.svg" });
    }
    for (let img of this.factoryImages) {
      if (img.filekey == null || img.filekey == "") {
        img.filekey = "assets/icon/profile/add.svg";
      } else if(img.filekey.indexOf('solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com')==-1){
        img.filekey = 'https://solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com/' + img.filekey;
      }
    }
  }
}

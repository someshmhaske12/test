import { Component, NgZone, OnInit } from '@angular/core';
import {FormBuilder, FormControl, Validators} from '@angular/forms';
import { OnboardingService } from 'src/app/user-onboarding/onboarding.service';
import { MatBottomSheet} from '@angular/material/bottom-sheet';
import { Router } from '@angular/router';
import {Location} from '@angular/common';
import { AddFactoryImagesComponent } from './add-factory-images/add-factory-images.component';
import { AddEmployeesComponent } from './add-employees/add-employees.component';
import { AddAddressComponent } from './add-address/add-address.component';
import { AddBankdetailsComponent } from './add-bankdetails/add-bankdetails.component';
import { AddDesignationComponent } from './add-designation/add-designation.component';
import { AddLogosComponent } from './add-logos/add-logos.component';
import { AddCatelogComponent } from './add-catelog/add-catelog.component';
import { AddProductComponent } from './add-product/add-product.component';
import { UserProfileService } from '../user-profile.service';
import { AppCommonDataModel } from 'src/app/shared/common/app-common.datamodel';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { NavController } from '@ionic/angular';


@Component({
  selector: 'app-profile-screen',
  templateUrl: './profile-screen.component.html',
  styleUrls: ['./profile-screen.component.scss']
})
export class ProfileScreenComponent implements OnInit {

  setGreenTick = false;
  

  constructor(private onboardingService: OnboardingService,
              private formBuilder: FormBuilder,
              private bottomSheet: MatBottomSheet,
              private userProfileService: UserProfileService,
              private _datamodel: AppCommonDataModel,
              private notifyService: NotifyService,
              private router: Router,
              private _location : Location,
              private navController: NavController
              ) {
      this.onboardingService.galleryClicked.subscribe((response) => {
        console.log(response, 'Successfully uploaded. Now can green tick.');
        this.setGreenTick = true;
      });
    }

    contactDetailsForm = this.formBuilder.group({
        companyAddress : new FormControl(''),
        contactOperation: new FormControl('', [Validators.required]),
      });

      introductionForm = this.formBuilder.group({
        aboutUs : new FormControl('', Validators.required),
      });

    ngOnInit() {
      this.userProfileService.updateUserProfile();
      console.log("profile screen component :"+this._datamodel.userProfile);
    }

  back() {
    console.log('backtohold');
    this.onboardingService.backClicked();
    //this.router.navigate(['dashboard/home']);

    this.navController.back();

    // this._location.back();


  }

  openBottomlogo(): void {
    console.log('hello');
    this.bottomSheet.open(AddLogosComponent, {
      data: {},
    });
  }
  openBottomFactory(): void {
    this.bottomSheet.open(AddFactoryImagesComponent);
  }
  addEmployeeStrength(): void {
    this.bottomSheet.open(AddEmployeesComponent);
  }
  addCompanyAddress(): void {
    this.bottomSheet.open(AddAddressComponent);
  }
  addBankDetails(): void {
    this.bottomSheet.open(AddBankdetailsComponent);
  }
  addDesignation(): void {
    this.bottomSheet.open(AddDesignationComponent);
  }
  openBottomCatelog(): void {
    this.bottomSheet.open(AddCatelogComponent);
  }
  openBottomProduct(): void {
    this.bottomSheet.open(AddProductComponent);
  }
  onSubmitCompanyDetails() {
    console.log(this.contactDetailsForm, 'companyAddress');
    
    this.userProfileService.updateOperationalAddress(this.contactDetailsForm.value.contactOperation)
    .subscribe(success => {
      // TODO On success
      this.introductionForm.reset();
      this.notifyService.showToast('Successfully updated the user profile!', 'close');
    });
  }
  settingPage() {
    console.log('setting page');
    this.router.navigate(['profile/setting']);
  }


  addAboutUs() {
    console.log(this.introductionForm.value.aboutUs, 'introComment');
    this.userProfileService.updateAboutUs(this.introductionForm.value.aboutUs)
    .subscribe(success => {
      // TODO On success
      this.notifyService.showToast('Successfully updated the user profile!', 'close');
    });
  }

}

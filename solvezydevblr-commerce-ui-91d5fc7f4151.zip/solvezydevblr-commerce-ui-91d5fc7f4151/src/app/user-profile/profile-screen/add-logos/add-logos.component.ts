import { Component, OnInit, Inject, OnChanges, SimpleChanges } from '@angular/core';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { OnboardingService } from '../../../user-onboarding/onboarding.service';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { ProfileScreenComponent } from '../profile-screen.component';
import { File } from '@ionic-native/file/ngx';
import { MatBottomSheet} from '@angular/material/bottom-sheet';
import { AddLogoImagesComponent } from '../add-logo-images/add-logo-images.component';
import { Base64 } from '@ionic-native/base64/ngx';
import { CommonService } from 'src/app/shared/common/common-service';

@Component({
  selector: 'app-add-logos',
  templateUrl: './add-logos.component.html',
  styleUrls: ['./add-logos.component.scss'],
})
export class AddLogosComponent implements OnInit {
files: any;
fileoptsobj;
toshow: any;
imgURL: string  | ArrayBuffer;
otpFailedFlag = false;
imagephoto: string  | ArrayBuffer;
  dataFiles: any;

  ngOnInit() {}
  ionViewDidEnter() {
    document.addEventListener('backbutton', function(e) {
      console.log('disable back button');
    }, false);
}
  constructor(private bottomSheetRef: MatBottomSheetRef<ProfileScreenComponent>,
              @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
              private onboardingService: OnboardingService,
              private notifyService: NotifyService,
              private camera: Camera,
              private bottomSheet: MatBottomSheet,
              public file: File
              ) {}

  cross() {
    this.bottomSheetRef.dismiss();
  }
  // openCamera(): void {
  //   const options: CameraOptions = {
  //     quality: 100,
  //     destinationType: this.camera.DestinationType.FILE_URI,
  //     encodingType: this.camera.EncodingType.JPEG,
  //     mediaType: this.camera.MediaType.PICTURE
  //   };
  //   this.camera.getPicture(options).then(
  //     (imageData) => {
  //       this.files = 'data:image/jpeg;base64,' + imageData;
  //       console.log( this.files);
  //       this.imageDoc(this.files)
  //     },
  //     err => {
  //       // Handle error
  //       console.log('Camera issue:' + err);
  //     }
  //   );
  // }

  openCamera() {
      const options: CameraOptions = {
        quality: 100,
        mediaType: this.camera.MediaType.PICTURE,
        destinationType: this.camera.DestinationType.FILE_URI,
        encodingType: this.camera.EncodingType.JPEG,
        // sourceType: 1,
        // correctOrientation: true,
      };
      // options.sourceType = 0;
      this.camera.getPicture(options).then((imageData) => {
        console.log(imageData, 'imageData');

        let data = imageData;
        console.log(data)
  //       const filePath = 'data';
  //       this.base64.encodeFile(filePath).then((base64File: string) => {
  // console.log(base64File);
        // const fileName = imageData.substring(imageData.lastIndexOf('/') + 1);
        // const path = imageData.substring(0, imageData.lastIndexOf('/') + 1);
        // this.file.readAsDataURL(path, fileName).then((base64data) => {
        //   console.log(base64data, 'base64Data');
        //   this.imagephoto = base64data;

  this.onboardingService.addlogo(data)
          .subscribe(
            (doc: any) => {
              console.log(doc);
              this.onboardingService.galleryClicked.emit(doc);
              this.bottomSheetRef.dismiss();
              this.notifyService.showToast('Image uploaded successfully');
              this.otpFailedFlag = true;
            }),
            // tslint:disable-next-line: no-unused-expression
            (err: any) => {
              this.bottomSheetRef.dismiss();
              this.notifyService.showToast('Please try again');
              this.otpFailedFlag = true;
              console.log('errerr');
              console.log(err);
            };
        // });
      }, (err) => {
      });
    }








  openGalery(event): void {
    this.files = event.target.files[0];
    this.imageDoc(event.target.files[0]);
  }

  imageDoc(files) {
    console.log(files);
    this.dataFiles = files;
    this.onboardingService.addlogo(files)
      .subscribe(
        (img: any) => {
          console.log(img);

          this.toshow = img.data.key;
          console.log(this.toshow);
          this.imgURL = this.onboardingService.getImageUrl(this.toshow);
          console.log(this.imgURL);

          this.bottomSheet.open(AddLogoImagesComponent, {
            data : img,
          });

          // this.onboardingService.galleryClicked.emit(img);
          // this.bottomSheetRef.dismiss();
          // this.notifyService.showToast('Image uploaded successfully');
          this.otpFailedFlag = true;
        },
        err => {
          // this.notifyService.showToast('Please select document type');
          this.otpFailedFlag = true;
          console.log('errerr');
          console.log(err);
        }
      );
  }
}

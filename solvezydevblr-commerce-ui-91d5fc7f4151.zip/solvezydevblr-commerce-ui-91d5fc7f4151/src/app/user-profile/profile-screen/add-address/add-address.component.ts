import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { UserProfileService } from '../../user-profile.service';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { AppCommonDataModel } from 'src/app/shared/common/app-common.datamodel';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { ProfileScreenComponent } from '../profile-screen.component';

@Component({
  selector: 'app-add-address',
  templateUrl: './add-address.component.html',
  styleUrls: ['./add-address.component.scss'],
})
export class AddAddressComponent {

  constructor(private bottomSheetRef: MatBottomSheetRef<ProfileScreenComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private formBuilder: FormBuilder,
    private userProfileService: UserProfileService,
    private notifyService: NotifyService,
    private _datamodel: AppCommonDataModel) {
  }

  addAddressForm = this.formBuilder.group({
    companyCheck: new FormControl(''),
    optionalAddress: new FormControl('', [Validators.required]),
  });
  
  cross() {
    this.bottomSheetRef.dismiss();
  }

  onSubmitAddress() {
    console.log(this.addAddressForm, 'companyCheck');
    this.userProfileService.updateAddress(this.addAddressForm.value.companyCheck, this.buildRegAddress(),
      this.addAddressForm.value.optionalAddress).subscribe(
        success => {
          //TODO success
          this.bottomSheetRef.dismiss();
          this.notifyService.showToast("Address updated successfully!", "close");
        }
      );
  }

  buildRegAddress(){
    if(this._datamodel.userProfile == null || this._datamodel.userProfile.registeredAddress == null){
      return null;
    }
    return this._datamodel.userProfile.registeredAddress.address;
  }

}

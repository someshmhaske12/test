import { Component, OnInit, Inject } from '@angular/core';
import { AddLogosComponent } from '../add-logos/add-logos.component';
import { MatBottomSheet} from '@angular/material/bottom-sheet';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { OnboardingService } from 'src/app/user-onboarding/onboarding.service';
import { NotifyService } from 'src/app/shared/common/notify.service';
import { CommonService } from 'src/app/shared/common/common-service';

@Component({
  selector: 'app-add-logo-images',
  templateUrl: './add-logo-images.component.html',
  styleUrls: ['./add-logo-images.component.scss'],
})
export class AddLogoImagesComponent implements OnInit {
  
  tokey: any;
  bucket :any;
  imgURL: string  | ArrayBuffer;
  constructor(private bottomSheetRef: MatBottomSheetRef<AddLogosComponent>,
              @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
              private onboardingService: OnboardingService,
              private notifyService: NotifyService,
              private _c:CommonService
              ) { }

  ngOnInit() {
    let sendkey = this.data;
    this.tokey = sendkey.data.key;
    this.bucket = sendkey.data.bucket;
      this.imageShow();
      }

      imageShow() {
        this.imgURL = this.onboardingService.getImageUrl(this.tokey);
  }
  cross() {
    this.bottomSheetRef.dismiss();
  }

  submit() {
    this._c.store.getSmeId().then(smeId=>{
      this.uploadLogo(smeId);
    });
  }
 
  private uploadLogo(smeId: string){
    let logo = {
      "smeId":smeId,
      "logo":{
        "bucketName" : this.bucket,
        "filekey":this.tokey
      }
    };
    // console.log(this.sendkey);
    this.onboardingService.logo(logo).subscribe(
      (res: any) => {
      console.log(res);
      this.bottomSheetRef.dismiss();
      this.notifyService.showToast('Image uploaded successfully');
      this.onboardingService.galleryClicked.emit(res);
      },
      err => {
        console.log('errerr');
        console.log(err);
      }
    );
  }

}

import { Component, OnInit, Inject } from "@angular/core";
import { UserProfileService } from "../../user-profile.service";
import { NotifyService } from "src/app/shared/common/notify.service";
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from "@angular/material";
import { ProfileScreenComponent } from "../profile-screen.component";
import { CommonService } from "src/app/shared/common/common-service";
import { AppCommonDataModel } from 'src/app/shared/common/app-common.datamodel';

@Component({
  selector: "app-add-employees",
  templateUrl: "./add-employees.component.html",
  styleUrls: ["./add-employees.component.scss"]
})
export class AddEmployeesComponent implements OnInit {
  empMinCount: number;
  empMaxCount: number;
  highlightClassName = "highlight";
  activeStrength="";

  constructor(
    private bottomSheetRef: MatBottomSheetRef<ProfileScreenComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private profileService: UserProfileService,
    private notifyService: NotifyService,
    private _c: CommonService,
    private dataModel : AppCommonDataModel
  ) {
    this.updatePreviousData();
  }

  ngOnInit() {
   this.updatePreviousData();
  }

  updatePreviousData(){
    if(this.dataModel.userProfile!=null && this.dataModel.userProfile.employeeStrength != null){
      let streangth = this.dataModel.userProfile.employeeStrength;
      this.activeStrength = streangth.min+"-"+streangth.max;
      this.empMinCount = isNaN(parseInt(streangth.min)) ? 0 : parseInt(streangth.min);
      this.empMaxCount = isNaN(parseInt(streangth.max)) ? 0 : parseInt(streangth.max);
    }
  }

  cross() {
    this.bottomSheetRef.dismiss();
  }

  selectEmpStrenght( min: number, max: number) {
    this.empMinCount = min;
    this.empMaxCount = max;
    this.activeStrength = min+"-"+max;
  }

  addEmpStrength() {
    this._c.store.getSmeId().then(smeId => {
      this.updateEmployeeStrength(smeId);
    });
  }

  private updateEmployeeStrength(smeId: string) {
    this.profileService.updateEmpStrength(this.empMinCount, this.empMaxCount).subscribe(success => {
      // TODO
      this.notifyService.showToast('Updated employee strength!', 'close');
      this.bottomSheetRef.dismiss();
    });
  }
}

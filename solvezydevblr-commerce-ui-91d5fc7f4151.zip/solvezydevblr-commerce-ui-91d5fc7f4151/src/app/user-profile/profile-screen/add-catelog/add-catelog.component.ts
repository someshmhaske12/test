import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-catelog',
  templateUrl: './add-catelog.component.html',
  styleUrls: ['./add-catelog.component.scss'],
})
export class AddCatelogComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

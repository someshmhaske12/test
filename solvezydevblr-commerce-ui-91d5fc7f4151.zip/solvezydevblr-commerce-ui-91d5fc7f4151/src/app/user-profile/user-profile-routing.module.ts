import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProfileScreenComponent } from './profile-screen/profile-screen.component';
import { TitlesComponent } from './titles/titles.component';
import { RegistrationAddressComponent } from './registration-address/registration-address.component';
import { EmployeeStrengthComponent } from './employee-strength/employee-strength.component';
import { FactoryImageComponent } from './factory-image/factory-image.component';
import { SettingsComponent } from './profile-screen/settings/settings.component';
import { SmeProfileComponent } from './sme-profile/sme-profile.component';



const routes: Routes = [
  {
    path: '',
    redirectTo: 'profile',
    pathMatch: 'full'
  },
  { path: 'profile', component: ProfileScreenComponent },
  { path: 'smeprofile/:smeId', component: SmeProfileComponent },
  { path: 'titles', component: TitlesComponent },
  { path: 'factoryImage', component: FactoryImageComponent },
  { path: 'employeeStrength', component: EmployeeStrengthComponent },
  { path: 'registrationAddress', component: RegistrationAddressComponent },
  { path: 'setting', component: SettingsComponent},
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class ProfileOnboardingRoutingModule { }

import { Injectable, NgZone } from '@angular/core';
import { BankDetail, Product, Image, UserProfile } from './model/user-profile-models';
import { CommonService } from '../shared/common/common-service';
import { Observable } from 'rxjs';
import {environment} from '../../environments/environment';
import { AppCommonDataModel } from '../shared/common/app-common.datamodel';
import { NotifyService } from '../shared/common/notify.service';

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {
  //TODO variable renaming
  private _e = environment;
  userProfileUrl = "https://apis.solvezy.net/commerce/api/v1/profile";
  productUrl = "https://apis.solvezy.net/commerce/api/v1/profile";
  profileUrl = "http://172.16.1.203:8080/smeprofile/api/v1/userprofile";


  constructor(private _c: CommonService,  
    private _dm:AppCommonDataModel,
    private notifyService: NotifyService,
    private ngZone:NgZone) { 
  }



  updateUserProfile(){
    this._c.store.getSmeId().then(value=>{
        console.log("Fetching user profile for smeId :",value);
        this.fetchUserProfile(value);
    })
   
  }

  //TODO remove duplicated function
  fetchUserProfile(smeId:string){
    this._c.api.get(this.userProfileUrl+"?smeId="+smeId, true).subscribe(
      success=>{
        this.ngZone.run(update=>{
          if(success.data.profileDetail != null){
            this._dm.userProfile = success.data.profileDetail;
            console.log(this._dm.userProfile);
          }
          if(success.data.customerDetail){
            this._dm.customerDetail = success.data.customerDetail;
          }
        });
      },
      error=>{
        this.notifyService.showToast("Unable to fetch cusomter details!");
      }
    );
  }


  updateAboutUs(aboutUs:string):Observable<any>{
    console.log("Updating AboutUs of us for ", this._dm.userProfile.smeId);
    return this._c.api.put(this.userProfileUrl, {"smeId":this._dm.userProfile.smeId,"aboustUs":aboutUs}, true);
  }

  updateOperationalAddress(operationalAddress:string){
    console.log("Updating AboutUs of us for ", this._dm.userProfile.smeId);
    return this._c.api.put(this.userProfileUrl, {"smeId":this._dm.userProfile.smeId,"operationalAddress":operationalAddress}, true);

  }

  updateAddress(isOprationalAddress:boolean, registeredAddress:string, operationalAddress:string):Observable<any>{
    let addressData = {"smeId":this._dm.userProfile.smeId,"registeredAddress":registeredAddress, "operationalAddress":operationalAddress};
    if(isOprationalAddress){
      addressData["operationalAddress"] = registeredAddress;
    }
    return this._c.api.put(this.userProfileUrl, addressData, true);
  }

  updateBankDetails(bankDetails:BankDetail):Observable<any>{
    let userProfile = this.buildUserProfile();
    userProfile.bankDetail = bankDetails;
    return this._c.api.put(this.userProfileUrl, userProfile, true);
  }

  updateDesignation(designation:string):Observable<any>{
    return this._c.api.put(this.userProfileUrl, {"smeId":this._dm.userProfile.smeId,"designation":designation}, true);
  }

  updateEmpStrength(min:number, max:number):Observable<any>{
      let empStrength = {"smeId":this._dm.userProfile.smeId, "employeeStrength":{"min":min, "max":max}};
      return this._c.api.put(this.userProfileUrl, empStrength, true);
  }

  createProduct(product:Product){
    product.smeId = this._dm.userProfile.smeId;
    return this._c.api.post(this.productUrl, product, true);
  }

  getProfileData(){
    return this._c.api.get(this.profileUrl);
  }

  updateFactoryImages(factory:Image[]){
    let userProfile = this.buildUserProfile();
    userProfile.factory = factory;
    return this._c.api.put(this.userProfileUrl, userProfile, true);
  }

  private buildUserProfile(){
    let userProfile:UserProfile = {} as any;
    userProfile.smeId = this._dm.userProfile.smeId;
    return userProfile;
  }
}

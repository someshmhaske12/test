import { Component, OnInit } from '@angular/core';
import { OnboardingService } from 'src/app/user-onboarding/onboarding.service';

@Component({
  selector: 'app-titles',
  templateUrl: './titles.component.html',
  styleUrls: ['./titles.component.scss'],
})
export class TitlesComponent implements OnInit {

  constructor(private onboardingService : OnboardingService) { }
  public businessData = {
    logo:'',
    factoryImage : [],
    employees : null,
    registrationAddress : ''
  }
  

  ngOnInit() {

  }

  back() {
    this.onboardingService.backClicked();
  }
}

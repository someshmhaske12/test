export interface UserProfile {
    name:string;
    smeId: string;
    solvId: string;
    phoneNumber: string;
    aboustUs: string;
    status: boolean;
    industryType: string;
    businessType: string;
    logo: Image;
    factory: Array<Image>;
    employeeStrength: Range;
    registeredAddress: Address;
    operationalAddress: Address;
    bankDetail: BankDetail;
    designation: string;
    user: Array<User>;
}

export interface User {
    emailId: string;
    mobileNumber: string;
    userName: string;
    isActive: boolean;
}

export interface Address {
    address: string;
}

export interface BankDetail {
    bankName:string
    name: string;
    accoutNumber: string;
    accountHolder: string;
    IFSC: string;
}

export interface Image {
    fileKey: string;
    bucketName: string;
}

export interface Range {
    min: string;
    max: string;
}

export interface Product {
    category: string;
    description: string;
    imageId: string;
    minOrderQty: number;
    size: number;
    sku: string;
    smeId: string;
    tags: Array<string>;
    title: string;
    unitPrice: number;
    attachedDocs:object;
    deleted:boolean;
}

export interface ProductAdded {
    title: string;
    unitPrice: number;
    category: string;
    imageId: string;
}

export interface CustomerDetails {
    id: string;
    solvId: string;
    customerName: string;
    gstNo: string;
    panNo: string;
    cin: string;
    mobileNo: string;
    yearOfEstablishment: string;
    industryType: string;
    aboutBusiness: string;
    emailId: string;
    aadharNo: number;
    companyStatus: string;
}
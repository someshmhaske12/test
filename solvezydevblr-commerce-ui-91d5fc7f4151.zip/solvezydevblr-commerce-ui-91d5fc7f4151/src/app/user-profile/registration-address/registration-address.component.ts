import { Component, OnInit } from '@angular/core';
import { OnboardingService } from 'src/app/user-onboarding/onboarding.service';

@Component({
  selector: 'app-registration-address',
  templateUrl: './registration-address.component.html',
  styleUrls: ['./registration-address.component.scss'],
})
export class RegistrationAddressComponent implements OnInit {

  constructor(private onboardingService : OnboardingService) { }

  public address = '';
  ngOnInit() {}
  back() {
    this.onboardingService.backClicked();
  }
  save(){
    
  }
}

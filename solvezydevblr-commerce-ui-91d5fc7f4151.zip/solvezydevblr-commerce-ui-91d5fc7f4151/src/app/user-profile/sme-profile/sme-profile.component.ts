import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Product } from '../model/user-profile-models';
import { CommonService } from 'src/app/shared/common/common-service';
import { NavController } from '@ionic/angular';
import { environment } from 'src/environments/environment';
import { NotifyService } from 'src/app/shared/common/notify.service';

@Component({
  selector: 'app-sme-profile',
  templateUrl: './sme-profile.component.html',
  styleUrls: ['./sme-profile.component.scss'],
})
export class SmeProfileComponent implements OnInit {

  activeSmeId: string;
  // TODO update type safty
  smeProfile: any;
  productUrl:string = "https://apis.solvezy.net/commerce/api/v1/products/product/sme?pageNo=1&pageSize=6&showDeleted=false&smeId=";
  profileUrl:string = "https://apis.solvezy.net/commerce/api/v1/profile?smeId=";
  products: Product[] = [];
  constructor(private router: Router,
              private activeRoute: ActivatedRoute,
              private _c:CommonService,
              private navCtrl: NavController,
              private notifyService:NotifyService ) { }

  ngOnInit() {
    this.activeRoute.params.subscribe(param => {
      this.activeSmeId = param['smeId'];
      this.updateData(param['smeId']);
    });
  }

  updateData(smeId:string) {
    console.log('updating sme profile data');
    this._c.api.get(this.productUrl+smeId, true).subscribe(
      response=>{
        if(response != null && response.data != null && response.data.list != null){
          this.products =  response.data.list;
        }
      }
    );
    this._c.api.get(this.profileUrl+smeId, true).subscribe(
      response=>{
        if(response != null && response.data != null && response.data.profileDetail!=null){
          this.smeProfile = response.data.profileDetail;
        }
      }
    );
  }
  back() {
    // this.router.navigateByUrl('/dashboard/home');
    this.navCtrl.back();
  }

  getImageUrl(imgkey) {
    return 'https://solvezy-dev-ocr-applog.s3.ap-south-1.amazonaws.com/' + imgkey;
  }

  message() {
    this.router.navigate(['/chat/chat-user', this.activeSmeId]);
  }

  async sendConnection(){
    const url = environment.url + '/connect/api/v1/sendconnection';
    const requestObj = {
      requesterSmeId: await this._c.store.getSmeId(),
      targetSmeId: this.activeSmeId
    };
    this.smeProfile.sentRequest = true;
    this._c.api.post(url, requestObj).subscribe(
      res => {
        console.log('Sent sucessfully', res);
        this.notifyService.notificationWithClassAndAction(
          'Connection request sent successfully!',
          'Okay',
          'blue-snackbar'
        );
      },
      err => {
        this.smeProfile.sentRequest = false;
        console.log('Failed connection request', err);
      }
    );
  }
}

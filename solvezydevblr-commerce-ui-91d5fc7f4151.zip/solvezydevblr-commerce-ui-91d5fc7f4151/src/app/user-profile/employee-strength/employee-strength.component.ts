import { Component, OnInit } from '@angular/core';
import { OnboardingService } from 'src/app/user-onboarding/onboarding.service';

@Component({
  selector: 'app-employee-strength',
  templateUrl: './employee-strength.component.html',
  styleUrls: ['./employee-strength.component.scss'],
})
export class EmployeeStrengthComponent implements OnInit {

  constructor(private onboardingService : OnboardingService) { }
  public employees = ['1-20', '20-70', '70-150', '150-200', '200-500', '500-1000',]
  public selEmployee = '';
  ngOnInit() { }
  
  ionViewDidEnter() {
    document.addEventListener("backbutton",function(e) {
      console.log("disable back button")
    }, false);
}

  back() {
    this.onboardingService.backClicked();
  }
  save(){
    console.log('sdfghj')
  }
}

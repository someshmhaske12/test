import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileOnboardingRoutingModule } from './user-profile-routing.module';
import { ProfileScreenComponent } from './profile-screen/profile-screen.component';
import { AppCommonModule } from '../shared/common/app-common.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialCustomModule } from '../shared/material-custom/material-custom.module';
import { IonicModule } from '@ionic/angular';
import { HttpClientModule } from '@angular/common/http';
import { TitlesComponent } from './titles/titles.component';


import { FactoryImageComponent } from './factory-image/factory-image.component';
import { EmployeeStrengthComponent } from './employee-strength/employee-strength.component';
import { RegistrationAddressComponent } from './registration-address/registration-address.component';
import { AddFactoryImagesComponent } from './profile-screen/add-factory-images/add-factory-images.component';
import { AddEmployeesComponent } from './profile-screen/add-employees/add-employees.component';
import { AddAddressComponent } from './profile-screen/add-address/add-address.component';
import { AddBankdetailsComponent } from './profile-screen/add-bankdetails/add-bankdetails.component';
import { AddDesignationComponent } from './profile-screen/add-designation/add-designation.component';
import { AddLogosComponent } from './profile-screen/add-logos/add-logos.component';
import { AddCatelogComponent } from './profile-screen/add-catelog/add-catelog.component';
import { AddProductComponent } from './profile-screen/add-product/add-product.component';
import { SettingsComponent } from './profile-screen/settings/settings.component';
import { SmeProfileComponent } from './sme-profile/sme-profile.component';
import { AddLogoImagesComponent } from './profile-screen/add-logo-images/add-logo-images.component';


@NgModule({
  declarations: [
    ProfileScreenComponent,
    TitlesComponent,
    FactoryImageComponent,
    EmployeeStrengthComponent,
    RegistrationAddressComponent,
    AddLogosComponent,
    AddLogoImagesComponent,
    AddFactoryImagesComponent,
    AddEmployeesComponent,
    AddAddressComponent,
    AddBankdetailsComponent,
    AddDesignationComponent,
    AddCatelogComponent,
    AddProductComponent,
    SettingsComponent,
    SmeProfileComponent
  ],
  imports: [
    CommonModule,
    ProfileOnboardingRoutingModule,
    HttpClientModule,
    IonicModule,
    MaterialCustomModule,
    ReactiveFormsModule,
    FormsModule,
    AppCommonModule
  ],
  entryComponents: [AddLogosComponent,
                    AddLogoImagesComponent,
                    AddFactoryImagesComponent,
                    AddEmployeesComponent,
                    AddAddressComponent,
                    AddBankdetailsComponent,
                    AddDesignationComponent,
                    AddCatelogComponent,
                    AddProductComponent
                  ]
})
export class UserProfileModule {}

console.log('ran');

const fs = require('fs');
const { exec } = require('child_process');

const oldPath = 'C:/projects/commerce/commerce-ui/platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk'
const newPath = 'C:/projects/commerce/commerce-ui/app-release-unsigned.apk'

fs.rename(oldPath, newPath, function (err) {
  if (err) throw err
  console.log('Successfully apk moved')
});

// keypass

// exec(`jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore solv-release.keyst
// ore -storepass madcatz9 app-release-unsigned.apk comm_key`, (err, stdout, stderr) => {
//   if (err) {
//     // node couldn't execute the command
//     console.log('error jarsigner command');
//     return;
//   }
//   console.log(`stdout: ${stdout}`);
//   console.log(`stderr: ${stderr}`);
// });

// exec(`./zipalign -v 4 app-release-unsigned.apk comm-v0.1.8.apk`, (err, stdout, stderr) => {
//   if (err) {
//     // node couldn't execute the command
//     console.log('error jarsigner command');
//     return;
//   }
//   console.log(`stdout: ${stdout}`);
//   console.log(`stderr: ${stderr}`);
// });
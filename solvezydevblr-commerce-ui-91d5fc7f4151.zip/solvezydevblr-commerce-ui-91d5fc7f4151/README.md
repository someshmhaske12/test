# README #
Commerce-UI is an hybrid app written on the ionic framework using angular lib.

### What is this repository for? commerce-ui

* Code repository for commerce
* 1.0
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Install node from https://nodejs.org/en/download/
* Restart Visual Studio
* Install ionic : npm install -g ionic
* Run: ionic serve


### Contribution guidelines ###

* TBD

### Who do I talk to? ###

* avinash.kumar@solvezy.com
* pradeep.kumar@solvezy.com
* praveen.shivapur@solvezy.com

### How to build android apk
* update build.gradle under platform/android
    repositories {
        google()
        mavenLocal()
        jcenter()
    }
when trying to build for first time for the first time
* cmd> ionic cordova platform add android
* cmd> ionic cordova build android
for detailed run add --verbose
* cmd> ionic cordova build android --verbose
ouput location: {repoPath}\commerce-ui\platforms\android\app\build\outputs\apk\debug

### Android build -- Signed apk

* please download and install Android SDK( set ANDROID_HOME in path) and Gradle place it as C:\Gradle\gradle-5.6.2 ( for windows) 
Enter the following command to make the android prod/signed release 
* cmd> ionic cordova build android --release
* cmd> ionic cordova build android --release --verbose ( for added logs)
Signing using the key (my-release-key.keystore as part of the Teams repo and the following command works if we are running the command from the below mentioned output location FYI, else provide the relative path )
keystore: https://solvezy.sharepoint.com/sites/SolvConnect1.0Team/Shared%20Documents/General/Ionic/my-release-key.keystore
* cmd> jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore my-release-key.keystore -storepass Solvezy app-release-unsigned.apk solv
when prompted for Passphrase provide : Solvezy
* cmd> {PATH to Android SDK}\build-tools\29.0.2\zipalign -v 4 app-release-unsigned.apk solv-0.{version}.apk ( semantic )
ouput location: {repoPath}\commerce-ui\platforms\android\app\build\outputs\apk\release

### Mobile Web Build
* cmd> ionic cordova build browser --release
ouput location: {repoPath}\commerce-ui\platforms\android\app\build\outputs\browser\release

Please reach out to pradeep.kumar@solvezy.com for any queries
